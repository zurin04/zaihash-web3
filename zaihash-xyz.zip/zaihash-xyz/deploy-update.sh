#!/bin/bash

# Ubuntu Server Update Deployment Script
# This script updates the application on Ubuntu server

set -e

APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"
BACKUP_DIR="/var/backups/${APP_NAME}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

# Create backup
print_status "Creating backup..."
mkdir -p ${BACKUP_DIR}
timestamp=$(date +%Y%m%d_%H%M%S)
tar -czf ${BACKUP_DIR}/backup_${timestamp}.tar.gz -C ${APP_DIR} . --exclude=node_modules --exclude=dist

# Stop the application
print_status "Stopping application..."
systemctl stop ${APP_NAME} || true
sudo -u www-data pm2 stop ecosystem.config.js || true

# Install dependencies
print_status "Installing dependencies..."
cd ${APP_DIR}
sudo -u www-data npm install --production

# Build the application
print_status "Building application..."
sudo -u www-data npm run build

# Update database schema
print_status "Updating database schema..."
sudo -u www-data npm run db:push

# Start the application
print_status "Starting application..."
sudo -u www-data pm2 start ecosystem.config.js
systemctl start ${APP_NAME}

# Reload Nginx
print_status "Reloading Nginx..."
systemctl reload nginx

# Check application status
sleep 5
if systemctl is-active --quiet ${APP_NAME}; then
    print_status "✅ Application updated and running successfully!"
else
    print_error "❌ Application failed to start. Check logs: journalctl -u ${APP_NAME}"
    exit 1
fi

print_status "🔍 Checking application health..."
if curl -f http://localhost:3000/health >/dev/null 2>&1; then
    print_status "✅ Application health check passed!"
else
    print_warning "⚠️  Health check failed. Application may still be starting..."
fi

print_status "📊 Application status:"
systemctl status ${APP_NAME} --no-pager -l