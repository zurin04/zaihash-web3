#!/bin/bash

# Test script to verify PM2 deployment configuration
echo "Testing PM2 deployment configuration..."

# Create test PM2 config
cat > test-ecosystem.config.cjs <<EOF
module.exports = {
  apps: [{
    name: 'crypto-airdrop-test',
    script: 'tsx',
    args: 'server/index.ts',
    cwd: process.cwd(),
    interpreter: 'node',
    env: {
      NODE_ENV: 'production',
      PORT: 5001,
      DATABASE_URL: process.env.DATABASE_URL
    },
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    time: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};
EOF

# Test if PM2 can parse the config
echo "Testing PM2 configuration syntax..."
if node -e "require('./test-ecosystem.config.cjs')"; then
    echo "✓ PM2 configuration syntax is valid"
else
    echo "✗ PM2 configuration has syntax errors"
    exit 1
fi

# Cleanup
rm test-ecosystem.config.cjs

echo "✓ All deployment tests passed"