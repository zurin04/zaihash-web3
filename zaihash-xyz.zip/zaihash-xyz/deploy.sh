#!/bin/bash

# Ubuntu Server Deployment Script for Crypto Airdrop Platform
# This script sets up the application for production deployment

set -e

echo "🚀 Starting Ubuntu Server Deployment Setup..."

# Variables
APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"
DB_NAME="crypto_airdrop_db"
DB_USER="crypto_airdrop_user"
NGINX_CONF="/etc/nginx/sites-available/${APP_NAME}"
SYSTEMD_SERVICE="/etc/systemd/system/${APP_NAME}.service"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

# Update system packages
print_status "Updating system packages..."
apt update && apt upgrade -y

# Install required packages
print_status "Installing required packages..."
apt install -y curl wget gnupg2 software-properties-common apt-transport-https ca-certificates lsb-release

# Install Node.js 20
print_status "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PM2 globally
print_status "Installing PM2..."
npm install -g pm2

# Install PostgreSQL
print_status "Installing PostgreSQL..."
apt install -y postgresql postgresql-contrib

# Install Nginx
print_status "Installing Nginx..."
apt install -y nginx

# Install UFW firewall
print_status "Setting up firewall..."
apt install -y ufw
ufw allow ssh
ufw allow 'Nginx Full'
ufw --force enable

# Create application directory
print_status "Creating application directory..."
mkdir -p ${APP_DIR}
chown -R www-data:www-data ${APP_DIR}

# Create PM2 log directory
print_status "Creating PM2 log directory..."
mkdir -p /var/log/pm2
chown -R www-data:www-data /var/log/pm2

# Generate random password for database
DB_PASSWORD=$(openssl rand -base64 32)

# Setup PostgreSQL
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
CREATE DATABASE ${DB_NAME};
CREATE USER ${DB_USER} WITH ENCRYPTED PASSWORD '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
ALTER USER ${DB_USER} CREATEDB;
\q
EOF

# Create .env file template
print_status "Creating environment configuration..."
cat > ${APP_DIR}/.env << EOF
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
PGHOST=localhost
PGPORT=5432
PGUSER=${DB_USER}
PGPASSWORD=${DB_PASSWORD}
PGDATABASE=${DB_NAME}
SESSION_SECRET=$(openssl rand -base64 64)
EOF

# Set proper permissions for .env file
chown www-data:www-data ${APP_DIR}/.env
chmod 600 ${APP_DIR}/.env

# Create systemd service file
print_status "Creating systemd service..."
cat > ${SYSTEMD_SERVICE} << EOF
[Unit]
Description=Crypto Airdrop Platform
Documentation=https://github.com/your-repo/crypto-airdrop
After=network.target postgresql.service

[Service]
Type=forking
User=www-data
WorkingDirectory=${APP_DIR}
Environment=NODE_ENV=production
EnvironmentFile=${APP_DIR}/.env
ExecStart=/usr/bin/pm2 start ecosystem.config.js --no-daemon
ExecReload=/usr/bin/pm2 reload ecosystem.config.js
ExecStop=/usr/bin/pm2 stop ecosystem.config.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Create Nginx configuration
print_status "Creating Nginx configuration..."
cat > ${NGINX_CONF} << EOF
server {
    listen 80;
    server_name _;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline' 'unsafe-eval'" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json;
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone \$binary_remote_addr zone=login:10m rate=1r/s;
    
    # Main application
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
    
    # WebSocket support
    location /ws {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # API rate limiting
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Login endpoint with stricter rate limiting
    location /api/auth/login {
        limit_req zone=login burst=5 nodelay;
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        proxy_pass http://127.0.0.1:3000;
    }
    
    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF

# Enable Nginx site
ln -sf ${NGINX_CONF} /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
nginx -t

# Create deployment info file
print_status "Creating deployment information..."
cat > /root/deployment-info.txt << EOF
Crypto Airdrop Platform - Ubuntu Server Deployment
=================================================
Deployment Date: $(date)
Application Directory: ${APP_DIR}
Database: ${DB_NAME}
Database User: ${DB_USER}
Database Password: ${DB_PASSWORD}

Default Admin Credentials:
Username: admin
Password: admin123

Management Commands:
- Deploy new version: ./deploy-update.sh
- View logs: sudo journalctl -u ${APP_NAME} -f
- PM2 logs: sudo -u www-data pm2 logs
- Restart app: sudo systemctl restart ${APP_NAME}
- Nginx reload: sudo systemctl reload nginx
- Database access: sudo -u postgres psql -d ${DB_NAME}

File Locations:
- App: ${APP_DIR}
- Nginx config: ${NGINX_CONF}
- Service: ${SYSTEMD_SERVICE}
- Logs: /var/log/pm2/
- Environment: ${APP_DIR}/.env

Security Notes:
- Change admin password immediately after first login
- Setup SSL with Let's Encrypt: sudo certbot --nginx
- Review firewall rules: sudo ufw status
- Monitor logs regularly for security issues

Next Steps:
1. Copy your application files to ${APP_DIR}
2. Run: cd ${APP_DIR} && npm install --production
3. Run: npm run build
4. Run: npm run db:push
5. Run: npm run db:seed
6. Run: sudo systemctl enable ${APP_NAME}
7. Run: sudo systemctl start ${APP_NAME}
8. Run: sudo systemctl start nginx
EOF

chmod 600 /root/deployment-info.txt

print_status "✅ Ubuntu Server setup completed!"
print_status "📋 Deployment information saved to: /root/deployment-info.txt"
print_status "🔧 Next: Copy your app files to ${APP_DIR} and follow the steps in deployment-info.txt"