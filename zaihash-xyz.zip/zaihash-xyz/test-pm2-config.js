// Test PM2 configuration to verify deployment fixes
module.exports = {
  apps: [{
    name: 'crypto-airdrop-test',
    script: 'npx',
    args: 'tsx server/index.ts',
    cwd: process.cwd(),
    env: {
      NODE_ENV: 'production',
      PORT: 5001,
      DATABASE_URL: process.env.DATABASE_URL
    },
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    time: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};