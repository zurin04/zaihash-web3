# Ubuntu Server Deployment Guide

## Quick Start Deployment

### Prerequisites
- Ubuntu 20.04 LTS or newer
- Root access or sudo privileges
- Domain name (optional but recommended)

### One-Command Deployment
```bash
# Download and run the deployment script
curl -fsSL https://raw.githubusercontent.com/your-repo/crypto-airdrop/main/deploy.sh | sudo bash
```

### Manual Deployment Steps

1. **Prepare the server**
```bash
sudo chmod +x deploy.sh
sudo ./deploy.sh
```

2. **Upload your application**
```bash
# Copy files to server
scp -r . user@your-server:/var/www/crypto-airdrop/

# Or use git
cd /var/www/crypto-airdrop
git clone https://github.com/your-repo/crypto-airdrop.git .
```

3. **Install and build**
```bash
cd /var/www/crypto-airdrop
sudo -u www-data npm install --production
sudo -u www-data npm run build
sudo -u www-data npm run db:push
sudo -u www-data npm run db:seed
```

4. **Start services**
```bash
sudo systemctl enable crypto-airdrop
sudo systemctl start crypto-airdrop
sudo systemctl enable nginx
sudo systemctl start nginx
```

## Service Management

### Application Control
```bash
# Start/stop/restart application
sudo systemctl start crypto-airdrop
sudo systemctl stop crypto-airdrop
sudo systemctl restart crypto-airdrop

# Check status
sudo systemctl status crypto-airdrop

# View logs
sudo journalctl -u crypto-airdrop -f
```

### PM2 Management
```bash
# PM2 commands (run as www-data)
sudo -u www-data pm2 status
sudo -u www-data pm2 logs
sudo -u www-data pm2 restart crypto-airdrop
sudo -u www-data pm2 reload crypto-airdrop
```

### Database Management
```bash
# Access database
sudo -u postgres psql -d crypto_airdrop_db

# Create backup
sudo -u postgres pg_dump crypto_airdrop_db > backup.sql

# Restore backup
sudo -u postgres psql -d crypto_airdrop_db < backup.sql
```

## Security Configuration

### SSL Setup with Let's Encrypt
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot --nginx -d yourdomain.com

# Auto-renewal
sudo systemctl enable certbot.timer
```

### Firewall Setup
```bash
# Configure UFW
sudo ufw enable
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw status
```

### Security Hardening
```bash
# Disable root login
sudo sed -i 's/PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
sudo systemctl restart ssh

# Install fail2ban
sudo apt install fail2ban
sudo systemctl enable fail2ban
```

## Monitoring and Maintenance

### System Monitoring
```bash
# Run health checks
sudo ./server-monitor.sh

# Setup automated monitoring (every 5 minutes)
echo "*/5 * * * * root /var/www/crypto-airdrop/server-monitor.sh" | sudo tee -a /etc/crontab

# Setup log rotation
sudo cp logrotate.conf /etc/logrotate.d/crypto-airdrop
```

### Performance Optimization
```bash
# Optimize PostgreSQL
sudo -u postgres psql << 'EOF'
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET default_statistics_target = 100;
SELECT pg_reload_conf();
EOF

# Optimize Node.js
echo 'export NODE_OPTIONS="--max-old-space-size=512"' >> /etc/environment
```

## Updating the Application

### Automated Update
```bash
sudo ./deploy-update.sh
```

### Manual Update
```bash
cd /var/www/crypto-airdrop
git pull origin main
sudo -u www-data npm install --production
sudo -u www-data npm run build
sudo -u www-data npm run db:push
sudo systemctl restart crypto-airdrop
```

## Troubleshooting

### Common Issues

**Application won't start**
```bash
# Check logs
sudo journalctl -u crypto-airdrop -n 50
sudo -u www-data pm2 logs crypto-airdrop

# Check environment variables
sudo -u www-data cat /var/www/crypto-airdrop/.env

# Verify database connection
sudo -u postgres psql -d crypto_airdrop_db -c "SELECT 1;"
```

**High CPU/Memory Usage**
```bash
# Check resource usage
htop
sudo -u www-data pm2 monit

# Restart with memory limit
sudo -u www-data pm2 restart crypto-airdrop --max-memory-restart 512M
```

**Database Issues**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql
sudo -u postgres psql -c "SELECT version();"

# Check database connections
sudo -u postgres psql -c "SELECT * FROM pg_stat_activity;"
```

**SSL Certificate Issues**
```bash
# Check certificate status
sudo certbot certificates

# Renew certificate
sudo certbot renew --dry-run
sudo certbot renew
```

## File Locations

- Application: `/var/www/crypto-airdrop/`
- Environment: `/var/www/crypto-airdrop/.env`
- Nginx config: `/etc/nginx/sites-available/crypto-airdrop`
- Systemd service: `/etc/systemd/system/crypto-airdrop.service`
- PM2 logs: `/var/log/pm2/`
- Database backups: `/var/backups/crypto-airdrop/`
- Deployment info: `/root/deployment-info.txt`

## Environment Variables

### Required Variables
```bash
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://user:pass@localhost:5432/crypto_airdrop_db
PGHOST=localhost
PGPORT=5432
PGUSER=crypto_airdrop_user
PGPASSWORD=secure_password
PGDATABASE=crypto_airdrop_db
SESSION_SECRET=your_64_character_secret
```

### Optional Variables
```bash
# Enable auto-updates
AUTO_UPDATE=true

# Email alerts
ALERT_EMAIL=admin@yourdomain.com

# Custom API endpoints
CRYPTO_API_URL=https://api.coingecko.com/api/v3
```

## Performance Benchmarks

### Expected Performance
- **Concurrent Users**: 100-500 (depending on VPS specs)
- **Response Time**: < 200ms for API calls
- **Memory Usage**: 200-500MB
- **CPU Usage**: 10-30% under normal load

### Load Testing
```bash
# Install Apache Bench
sudo apt install apache2-utils

# Test API endpoint
ab -n 1000 -c 10 http://localhost:3000/api/crypto/prices

# Test health endpoint
ab -n 10000 -c 50 http://localhost:3000/health
```

## Backup Strategy

### Automated Backups
```bash
# Database backup (runs weekly via cron)
sudo -u postgres pg_dump crypto_airdrop_db | gzip > /var/backups/crypto-airdrop/db/backup_$(date +%Y%m%d).sql.gz

# Application backup
tar -czf /var/backups/crypto-airdrop/app/backup_$(date +%Y%m%d).tar.gz -C /var/www/crypto-airdrop . --exclude=node_modules --exclude=dist
```

### Restore Procedures
```bash
# Restore database
sudo systemctl stop crypto-airdrop
sudo -u postgres psql -d crypto_airdrop_db -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"
zcat /var/backups/crypto-airdrop/db/backup_20240101.sql.gz | sudo -u postgres psql -d crypto_airdrop_db
sudo systemctl start crypto-airdrop

# Restore application
sudo systemctl stop crypto-airdrop
cd /var/www/crypto-airdrop
sudo tar -xzf /var/backups/crypto-airdrop/app/backup_20240101.tar.gz
sudo chown -R www-data:www-data .
sudo systemctl start crypto-airdrop
```

## Support and Maintenance

### Regular Maintenance Tasks
- **Daily**: Check logs and system status
- **Weekly**: Update system packages and create backups
- **Monthly**: Review security logs and update dependencies
- **Quarterly**: Full system security audit

### Getting Help
```bash
# View deployment information
cat /root/deployment-info.txt

# Check system health
sudo ./server-monitor.sh

# View all logs
sudo journalctl -u crypto-airdrop -u nginx -u postgresql --since "1 hour ago"
```