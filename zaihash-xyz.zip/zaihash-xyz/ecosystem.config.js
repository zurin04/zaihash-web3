module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'dist/index.js',
    cwd: '/var/www/crypto-airdrop',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/var/log/pm2/crypto-airdrop-error.log',
    out_file: '/var/log/pm2/crypto-airdrop-out.log',
    log_file: '/var/log/pm2/crypto-airdrop.log',
    time: true,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    max_restarts: 10,
    min_uptime: '10s',
    restart_delay: 4000
  }]
};