# Production Deployment Guide

## Quick Deployment Commands

### Pre-deployment Validation
```bash
node scripts/pre-check.js
```

### Production Setup (VPS/Server)
```bash
chmod +x scripts/production-setup.sh
sudo scripts/production-setup.sh
```

### Health Monitoring
```bash
node scripts/error-check.js
```

## Manual Deployment Steps

### 1. Server Requirements
- Ubuntu 20.04+ or Debian 11+
- Minimum 1GB RAM, 10GB storage
- Root or sudo access

### 2. Environment Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install -y curl git ufw fail2ban nginx certbot
```

### 3. Database Setup
The production script automatically:
- Installs PostgreSQL
- Creates secure database with random password
- Configures proper permissions
- Sets up schema and seed data

### 4. Application Configuration
```bash
# Clone your repository
git clone <your-repo-url> /var/www/crypto-airdrop
cd /var/www/crypto-airdrop

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt-get install -y nodejs

# Install dependencies and build
npm ci
npm run build
```

### 5. Process Management (PM2)
```bash
# Install PM2
sudo npm install -g pm2

# Start application
pm2 start npm --name "crypto-airdrop" -- start

# Enable startup script
pm2 startup
pm2 save
```

### 6. Web Server (Nginx)
```bash
# Configure Nginx proxy (see production script for full config)
sudo nginx -t
sudo systemctl reload nginx
```

### 7. Security Setup
```bash
# Configure firewall
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# Setup SSL (after DNS is configured)
sudo certbot --nginx -d yourdomain.com
```

## Post-Deployment

### Default Access
- URL: `http://your-server-ip`
- Admin: `admin` / `admin123`

### Essential Tasks
1. Change default admin password immediately
2. Configure domain DNS to point to server
3. Set up SSL certificate
4. Review and customize site settings

### Management Commands
```bash
# View application logs
sudo -u www-data pm2 logs crypto-airdrop

# Restart application
sudo -u www-data pm2 restart crypto-airdrop

# Check system status
sudo -u www-data pm2 status
systemctl status nginx
systemctl status postgresql

# Database access
sudo -u postgres psql -d crypto_airdrop_db

# Update application
cd /var/www/crypto-airdrop
git pull origin main
npm ci
npm run build
sudo -u www-data pm2 restart crypto-airdrop
```

### Monitoring & Maintenance
```bash
# Run health check
node scripts/error-check.js

# Check disk space
df -h

# Check memory usage
free -m

# View system logs
sudo journalctl -u nginx -f
sudo journalctl -u postgresql -f

# Database backup
sudo -u postgres pg_dump crypto_airdrop_db > backup-$(date +%Y%m%d).sql
```

## Troubleshooting

### Application Not Starting
```bash
# Check PM2 status
sudo -u www-data pm2 logs crypto-airdrop --lines 50

# Check database connection
sudo -u postgres psql -c "SELECT 1;"

# Verify environment variables
cat /var/www/crypto-airdrop/.env.production
```

### Database Issues
```bash
# Reset database schema
cd /var/www/crypto-airdrop
npm run db:push
npm run db:seed

# Check database connections
sudo -u postgres psql -d crypto_airdrop_db -c "\dt"
```

### Nginx Issues
```bash
# Test configuration
sudo nginx -t

# Check error logs
sudo tail -f /var/log/nginx/error.log

# Restart services
sudo systemctl restart nginx
```

### Performance Issues
```bash
# Monitor resource usage
htop
iostat
netstat -tuln

# PM2 monitoring
sudo -u www-data pm2 monit

# Database performance
sudo -u postgres psql -d crypto_airdrop_db -c "SELECT * FROM pg_stat_activity;"
```

## Security Checklist

- [ ] Default passwords changed
- [ ] Firewall configured (UFW)
- [ ] Fail2ban active
- [ ] SSL certificate installed
- [ ] Database password secured
- [ ] SSH key authentication enabled
- [ ] Regular security updates scheduled
- [ ] Backup strategy implemented

## Backup Strategy

### Automated Daily Backup
```bash
# Add to crontab (sudo crontab -e)
0 2 * * * sudo -u postgres pg_dump crypto_airdrop_db > /backup/db-$(date +\%Y\%m\%d).sql
0 3 * * * tar -czf /backup/app-$(date +\%Y\%m\%d).tar.gz /var/www/crypto-airdrop
```

### Manual Backup
```bash
# Database backup
sudo -u postgres pg_dump crypto_airdrop_db > backup.sql

# Application backup
tar -czf app-backup.tar.gz /var/www/crypto-airdrop

# Restore database
sudo -u postgres psql crypto_airdrop_db < backup.sql
```

## Performance Optimization

### Database Optimization
```sql
-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_airdrops_status ON airdrops(status);
CREATE INDEX IF NOT EXISTS idx_airdrops_category ON airdrops(category_id);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
```

### Nginx Optimization
- Enable gzip compression
- Configure caching headers
- Set up rate limiting
- Enable HTTP/2

### Application Optimization
- PM2 cluster mode for multiple CPU cores
- Database connection pooling
- Static file serving via Nginx
- CDN for assets (optional)

## Scaling Considerations

### Horizontal Scaling
- Load balancer (Nginx/HAProxy)
- Multiple application instances
- Database read replicas
- CDN for static assets

### Vertical Scaling
- Increase server resources
- Database performance tuning
- Redis caching layer
- Session store optimization

## Support

For production issues:
1. Run health check: `node scripts/error-check.js`
2. Check application logs: `sudo -u www-data pm2 logs crypto-airdrop`
3. Verify system services: `systemctl status nginx postgresql`
4. Review error logs: `sudo journalctl -u nginx`