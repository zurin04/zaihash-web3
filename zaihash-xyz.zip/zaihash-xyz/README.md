# Crypto Airdrop Platform

A comprehensive crypto learning and engagement platform that empowers users to explore, learn, and participate in cryptocurrency ecosystems through advanced user management, creator application workflows, and role-based access controls.

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL + Drizzle ORM
- **Styling**: Tailwind CSS + shadcn/ui
- **Authentication**: Passport.js + Web3 wallet support
- **Real-time**: WebSocket chat system

## Development Setup

### Prerequisites
- Node.js 18+
- PostgreSQL database
- npm or yarn

### Quick Start

1. **Clone and install dependencies**:
   ```bash
   git clone <repository-url>
   cd crypto-airdrop-platform
   npm install
   ```

2. **Set up environment variables**:
   ```bash
   cp .env.example .env
   # Edit .env with your database URL and other settings
   ```

3. **Initialize database**:
   ```bash
   npm run db:push
   npm run db:seed
   ```

4. **Start development server**:
   ```bash
   npm run dev
   ```

## Production Deployment

### Pre-deployment Validation

Before deploying to production, validate your setup:

```bash
npm run check:production
```

This checks:
- Node.js and npm versions
- Required files and dependencies
- Environment configuration
- TypeScript compilation
- Database connectivity

### Production Setup

For complete production deployment on a VPS:

```bash
# Make scripts executable
chmod +x scripts/production-setup.sh

# Run production setup (requires root/sudo)
sudo scripts/production-setup.sh
```

The setup script:
- Installs Node.js, PostgreSQL, Nginx, PM2
- Configures security (firewall, fail2ban)
- Sets up SSL-ready Nginx proxy
- Creates database with secure credentials
- Builds and starts the application
- Configures process management

### Health Monitoring

Check system health and troubleshoot issues:

```bash
npm run check:health
```

This monitors:
- System services (Nginx, PostgreSQL, PM2)
- Application process status
- Database connectivity
- Error logs analysis
- Resource usage
- Network connectivity

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run db:push` - Push database schema
- `npm run db:seed` - Seed database with initial data
- `npm run check:production` - Validate production readiness
- `npm run check:health` - System health check

## Features

- **User Management**: Registration, authentication, role-based access
- **Web3 Integration**: Wallet connection and SIWE authentication
- **Airdrop Management**: Create, manage, and track crypto airdrops
- **Real-time Chat**: Live community chat with admin controls
- **Creator System**: Application workflow for content creators
- **Crypto Prices**: Live cryptocurrency price feeds
- **Admin Dashboard**: Comprehensive admin panel
- **Mobile Responsive**: Optimized for all devices

## Default Credentials

After initial setup:
- **Admin**: `admin` / `admin123`

**Important**: Change default passwords immediately after deployment.

## Support

For production issues:

1. Check health status: `npm run check:health`
2. View application logs: `sudo -u www-data pm2 logs crypto-airdrop`
3. Check system logs: `sudo journalctl -u nginx`
4. Verify services: `systemctl status nginx postgresql`