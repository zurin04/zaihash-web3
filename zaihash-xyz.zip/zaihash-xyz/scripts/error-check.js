#!/usr/bin/env node

import fs from 'fs';
import { execSync } from 'child_process';

class ErrorChecker {
  constructor() {
    this.issues = [];
    this.info = [];
  }

  log(message, type = 'info') {
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    const icons = {
      info: 'ℹ',
      success: '✓',
      warning: '⚠',
      error: '✗'
    };

    console.log(`${colors[type]}${icons[type]} ${message}${colors.reset}`);
  }

  async checkSystemServices() {
    this.log('Checking system services...', 'info');
    
    const services = ['nginx', 'postgresql'];
    
    for (const service of services) {
      try {
        const status = execSync(`systemctl is-active ${service}`, { encoding: 'utf8' }).trim();
        if (status === 'active') {
          this.info.push(`${service} service is running`);
        } else {
          this.issues.push(`${service} service is not active (status: ${status})`);
        }
      } catch (error) {
        this.issues.push(`${service} service check failed: ${error.message}`);
      }
    }
  }

  async checkApplicationProcess() {
    this.log('Checking application process...', 'info');
    
    try {
      // Check if PM2 is available
      execSync('which pm2', { stdio: 'pipe' });
      
      try {
        const pm2Status = execSync('sudo -u www-data pm2 jlist', { encoding: 'utf8' });
        const processes = JSON.parse(pm2Status);
        
        const cryptoApp = processes.find(p => p.name === 'crypto-airdrop');
        
        if (cryptoApp) {
          if (cryptoApp.pm2_env.status === 'online') {
            this.info.push('Application is running via PM2');
            this.info.push(`Memory usage: ${Math.round(cryptoApp.memory / 1024 / 1024)}MB`);
            this.info.push(`CPU usage: ${cryptoApp.cpu}%`);
            this.info.push(`Uptime: ${Math.round(cryptoApp.pm2_env.pm_uptime / 1000 / 60)} minutes`);
          } else {
            this.issues.push(`Application status: ${cryptoApp.pm2_env.status}`);
          }
          
          if (cryptoApp.pm2_env.restart_time > 5) {
            this.issues.push(`Application has restarted ${cryptoApp.pm2_env.restart_time} times`);
          }
        } else {
          this.issues.push('Application not found in PM2 process list');
        }
      } catch (pm2Error) {
        this.info.push('PM2 not configured - checking direct process');
        
        // Check for Node.js process
        try {
          const nodeProcesses = execSync('pgrep -f "node.*server/index"', { encoding: 'utf8' });
          if (nodeProcesses.trim()) {
            this.info.push('Application running as Node.js process');
          } else {
            this.issues.push('No application process found');
          }
        } catch (nodeError) {
          this.issues.push('No application process detected');
        }
      }
    } catch (error) {
      this.info.push('PM2 not installed - development environment detected');
      
      // Check for development server
      try {
        const devProcess = execSync('pgrep -f "tsx.*server"', { encoding: 'utf8' });
        if (devProcess.trim()) {
          this.info.push('Development server is running');
        } else {
          this.issues.push('No development process found');
        }
      } catch (devError) {
        this.issues.push('No application process detected');
      }
    }
  }

  async checkApplicationLogs() {
    this.log('Checking recent application logs...', 'info');
    
    try {
      const logs = execSync('sudo -u www-data pm2 logs crypto-airdrop --lines 50 --nostream', { encoding: 'utf8' });
      
      // Check for common error patterns
      const errorPatterns = [
        /error/i,
        /exception/i,
        /failed/i,
        /timeout/i,
        /connection refused/i,
        /enotfound/i,
        /econnreset/i
      ];
      
      const logLines = logs.split('\n');
      const recentErrors = logLines.filter(line => 
        errorPatterns.some(pattern => pattern.test(line))
      ).slice(-10); // Last 10 errors
      
      if (recentErrors.length > 0) {
        this.issues.push(`Found ${recentErrors.length} recent error(s) in logs:`);
        recentErrors.forEach(error => {
          this.issues.push(`  ${error.trim()}`);
        });
      } else {
        this.info.push('No recent errors found in application logs');
      }
    } catch (error) {
      this.issues.push(`Log check failed: ${error.message}`);
    }
  }

  async checkDatabaseConnection() {
    this.log('Checking database connection...', 'info');
    
    try {
      // Test basic PostgreSQL connection
      const result = execSync('sudo -u postgres psql -c "SELECT version();" -t', { encoding: 'utf8' });
      if (result.includes('PostgreSQL')) {
        this.info.push('PostgreSQL database is accessible');
      }
      
      // Check if application database exists
      const dbCheck = execSync('sudo -u postgres psql -lqt | cut -d \\| -f 1 | grep -w crypto_airdrop_db', { encoding: 'utf8' });
      if (dbCheck.trim()) {
        this.info.push('Application database exists');
      } else {
        this.issues.push('Application database not found');
      }
      
    } catch (error) {
      this.issues.push(`Database connection check failed: ${error.message}`);
    }
  }

  async checkNginxConfiguration() {
    this.log('Checking Nginx configuration...', 'info');
    
    try {
      execSync('nginx -t', { stdio: 'pipe' });
      this.info.push('Nginx configuration is valid');
      
      // Check if application config exists
      if (fs.existsSync('/etc/nginx/sites-enabled/crypto-airdrop')) {
        this.info.push('Application Nginx configuration is enabled');
      } else {
        this.issues.push('Application Nginx configuration not found');
      }
      
    } catch (error) {
      this.issues.push(`Nginx configuration error: ${error.message}`);
    }
  }

  async checkApplicationConnectivity() {
    this.log('Checking application connectivity...', 'info');
    
    try {
      // Test local connection
      const response = execSync('curl -s -o /dev/null -w "%{http_code}" http://localhost:5000/', { encoding: 'utf8' });
      if (response === '200') {
        this.info.push('Application responds to direct requests');
      } else {
        this.issues.push(`Application returns HTTP ${response} instead of 200`);
      }
      
      // Test through Nginx
      const nginxResponse = execSync('curl -s -o /dev/null -w "%{http_code}" http://localhost/', { encoding: 'utf8' });
      if (nginxResponse === '200') {
        this.info.push('Application responds through Nginx proxy');
      } else {
        this.issues.push(`Nginx proxy returns HTTP ${nginxResponse} instead of 200`);
      }
      
    } catch (error) {
      this.issues.push(`Connectivity check failed: ${error.message}`);
    }
  }

  async checkDiskSpace() {
    this.log('Checking system resources...', 'info');
    
    try {
      const diskUsage = execSync('df -h / | tail -1', { encoding: 'utf8' });
      const usageMatch = diskUsage.match(/(\d+)%/);
      
      if (usageMatch) {
        const usage = parseInt(usageMatch[1]);
        if (usage > 90) {
          this.issues.push(`Disk usage is critical: ${usage}%`);
        } else if (usage > 80) {
          this.issues.push(`Disk usage is high: ${usage}%`);
        } else {
          this.info.push(`Disk usage: ${usage}%`);
        }
      }
      
      // Check memory usage
      const memInfo = execSync('free -m', { encoding: 'utf8' });
      const memMatch = memInfo.match(/Mem:\s+(\d+)\s+(\d+)/);
      
      if (memMatch) {
        const total = parseInt(memMatch[1]);
        const used = parseInt(memMatch[2]);
        const usage = Math.round((used / total) * 100);
        
        if (usage > 90) {
          this.issues.push(`Memory usage is critical: ${usage}%`);
        } else if (usage > 80) {
          this.issues.push(`Memory usage is high: ${usage}%`);
        } else {
          this.info.push(`Memory usage: ${usage}%`);
        }
      }
      
    } catch (error) {
      this.issues.push(`Resource check failed: ${error.message}`);
    }
  }

  async checkFirewall() {
    this.log('Checking firewall status...', 'info');
    
    try {
      const ufwStatus = execSync('ufw status', { encoding: 'utf8' });
      
      if (ufwStatus.includes('Status: active')) {
        this.info.push('UFW firewall is active');
        
        // Check required ports
        const requiredPorts = ['22/tcp', '80/tcp', '443/tcp'];
        requiredPorts.forEach(port => {
          if (ufwStatus.includes(port)) {
            this.info.push(`Port ${port} is allowed`);
          } else {
            this.issues.push(`Port ${port} is not allowed in firewall`);
          }
        });
      } else {
        this.issues.push('UFW firewall is not active');
      }
      
    } catch (error) {
      this.issues.push(`Firewall check failed: ${error.message}`);
    }
  }

  async generateReport() {
    console.log('\n' + '='.repeat(60));
    this.log('SYSTEM HEALTH REPORT', 'info');
    console.log('='.repeat(60));

    if (this.info.length > 0) {
      this.log(`\nSYSTEM STATUS (${this.info.length} items):`, 'success');
      this.info.forEach(item => this.log(`  ${item}`, 'success'));
    }

    if (this.issues.length > 0) {
      this.log(`\nISSUES FOUND (${this.issues.length} items):`, 'error');
      this.issues.forEach(item => this.log(`  ${item}`, 'error'));
      
      console.log('\n' + '='.repeat(60));
      this.log('TROUBLESHOOTING COMMANDS', 'info');
      console.log('='.repeat(60));
      
      console.log('\nService Management:');
      console.log('  sudo systemctl restart nginx');
      console.log('  sudo systemctl restart postgresql');
      console.log('  sudo -u www-data pm2 restart crypto-airdrop');
      
      console.log('\nLogs:');
      console.log('  sudo -u www-data pm2 logs crypto-airdrop');
      console.log('  sudo journalctl -u nginx -f');
      console.log('  sudo journalctl -u postgresql -f');
      
      console.log('\nConfiguration:');
      console.log('  sudo nginx -t');
      console.log('  sudo -u www-data pm2 status');
      
      console.log('\nDatabase:');
      console.log('  sudo -u postgres psql -d crypto_airdrop_db');
      
      return 1; // Exit code indicating issues found
    } else {
      console.log('');
      this.log('✅ All checks passed! System is healthy', 'success');
      return 0;
    }
  }

  async run() {
    this.log('🔍 Starting System Health Check', 'info');
    console.log('');

    await this.checkSystemServices();
    await this.checkApplicationProcess();
    await this.checkDatabaseConnection();
    await this.checkNginxConfiguration();
    await this.checkApplicationConnectivity();
    await this.checkDiskSpace();
    await this.checkFirewall();
    await this.checkApplicationLogs();

    const exitCode = await this.generateReport();
    process.exit(exitCode);
  }
}

// Run the error checker
const checker = new ErrorChecker();
checker.run().catch(error => {
  console.error('Health check failed:', error);
  process.exit(1);
});