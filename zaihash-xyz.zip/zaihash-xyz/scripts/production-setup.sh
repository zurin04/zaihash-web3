#!/bin/bash

# Production Setup Script for Crypto Airdrop Platform
# This script handles complete production deployment with error checking

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="crypto-airdrop"
APP_DIR="/var/www/${PROJECT_NAME}"
DB_NAME="crypto_airdrop_db"
DB_USER="crypto_user"
DB_PASSWORD=$(openssl rand -base64 32)
DOMAIN=${DOMAIN:-$(hostname -I | awk '{print $1}')}

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
    log_success "Running with root privileges"
}

# System update and dependencies
install_system_dependencies() {
    log_info "Updating system packages..."
    apt update -y
    apt upgrade -y
    
    log_info "Installing system dependencies..."
    apt install -y curl wget gnupg2 software-properties-common apt-transport-https ca-certificates \
                   build-essential git ufw fail2ban nginx certbot python3-certbot-nginx
    
    log_success "System dependencies installed"
}

# Install Node.js
install_nodejs() {
    log_info "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
    
    # Verify installation
    NODE_VERSION=$(node --version)
    NPM_VERSION=$(npm --version)
    
    log_success "Node.js ${NODE_VERSION} and npm ${NPM_VERSION} installed"
}

# Install PostgreSQL
setup_postgresql() {
    log_info "Installing PostgreSQL..."
    apt install -y postgresql postgresql-contrib
    
    # Start and enable PostgreSQL
    systemctl start postgresql
    systemctl enable postgresql
    
    log_info "Setting up database..."
    # Create database and user
    sudo -u postgres psql <<EOF
CREATE DATABASE ${DB_NAME};
CREATE USER ${DB_USER} WITH ENCRYPTED PASSWORD '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
ALTER DATABASE ${DB_NAME} OWNER TO ${DB_USER};
EOF
    
    log_success "PostgreSQL database configured"
}

# Setup application directory and files
setup_application() {
    log_info "Setting up application directory..."
    
    # Create application directory
    mkdir -p ${APP_DIR}
    
    # Copy application files (assuming we're in the project directory)
    if [[ $(pwd) != ${APP_DIR} ]]; then
        log_info "Copying application files..."
        cp -r . ${APP_DIR}/
    fi
    
    cd ${APP_DIR}
    
    # Create www-data user if it doesn't exist
    if ! id "www-data" &>/dev/null; then
        useradd -r -s /bin/false www-data
    fi
    
    # Set proper ownership
    chown -R www-data:www-data ${APP_DIR}
    
    log_success "Application directory configured"
}

# Install dependencies and build
build_application() {
    log_info "Installing Node.js dependencies..."
    cd ${APP_DIR}
    
    # Install dependencies as www-data user
    sudo -u www-data npm ci --production=false
    
    log_info "Building application..."
    sudo -u www-data npm run build
    
    log_success "Application built successfully"
}

# Setup environment variables
setup_environment() {
    log_info "Configuring environment variables..."
    
    # Create production environment file
    cat > ${APP_DIR}/.env.production <<EOF
NODE_ENV=production
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
SESSION_SECRET=$(openssl rand -base64 64)
PORT=5000
DOMAIN=${DOMAIN}
EOF
    
    chown www-data:www-data ${APP_DIR}/.env.production
    chmod 600 ${APP_DIR}/.env.production
    
    log_success "Environment configured"
}

# Setup database schema
setup_database_schema() {
    log_info "Setting up database schema..."
    cd ${APP_DIR}
    
    # Push database schema
    sudo -u www-data npm run db:push
    
    # Seed database
    sudo -u www-data npm run db:seed
    
    log_success "Database schema and seed data configured"
}

# Install PM2 process manager
setup_pm2() {
    log_info "Installing PM2 process manager..."
    npm install -g pm2
    
    # Create PM2 ecosystem file
    cat > ${APP_DIR}/ecosystem.config.js <<EOF
module.exports = {
  apps: [{
    name: '${PROJECT_NAME}',
    script: 'npm',
    args: 'start',
    cwd: '${APP_DIR}',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/pm2/${PROJECT_NAME}-error.log',
    out_file: '/var/log/pm2/${PROJECT_NAME}-out.log',
    log_file: '/var/log/pm2/${PROJECT_NAME}.log',
    time: true
  }]
}
EOF
    
    # Create PM2 log directory
    mkdir -p /var/log/pm2
    chown -R www-data:www-data /var/log/pm2
    
    # Start application with PM2
    sudo -u www-data pm2 start ${APP_DIR}/ecosystem.config.js
    sudo -u www-data pm2 save
    
    # Setup PM2 startup script
    pm2 startup systemd -u www-data --hp /var/www
    
    log_success "PM2 configured and application started"
}

# Configure Nginx
setup_nginx() {
    log_info "Configuring Nginx..."
    
    # Create Nginx configuration
    cat > /etc/nginx/sites-available/${PROJECT_NAME} <<EOF
server {
    listen 80;
    server_name ${DOMAIN};
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss;
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=login:10m rate=5r/m;
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
    
    location /api/auth {
        limit_req zone=login burst=3 nodelay;
        proxy_pass http://localhost:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Static files
    location /uploads/ {
        alias ${APP_DIR}/public/uploads/;
        expires 1M;
        add_header Cache-Control "public, immutable";
    }
}
EOF
    
    # Enable site
    ln -sf /etc/nginx/sites-available/${PROJECT_NAME} /etc/nginx/sites-enabled/
    
    # Remove default site
    rm -f /etc/nginx/sites-enabled/default
    
    # Test and restart Nginx
    nginx -t
    systemctl restart nginx
    systemctl enable nginx
    
    log_success "Nginx configured and started"
}

# Setup firewall
setup_firewall() {
    log_info "Configuring firewall..."
    
    # Reset UFW
    ufw --force reset
    
    # Default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH, HTTP, HTTPS
    ufw allow ssh
    ufw allow 80/tcp
    ufw allow 443/tcp
    
    # Enable firewall
    ufw --force enable
    
    log_success "Firewall configured"
}

# Setup security measures
setup_security() {
    log_info "Configuring security measures..."
    
    # Configure fail2ban for Nginx
    cat > /etc/fail2ban/jail.local <<EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[nginx-http-auth]
enabled = true

[nginx-noscript]
enabled = true

[nginx-badbots]
enabled = true

[nginx-noproxy]
enabled = true
EOF
    
    systemctl restart fail2ban
    systemctl enable fail2ban
    
    log_success "Security measures configured"
}

# Verify deployment
verify_deployment() {
    log_info "Verifying deployment..."
    
    # Check services
    if systemctl is-active --quiet nginx; then
        log_success "Nginx is running"
    else
        log_error "Nginx is not running"
        exit 1
    fi
    
    if systemctl is-active --quiet postgresql; then
        log_success "PostgreSQL is running"
    else
        log_error "PostgreSQL is not running"
        exit 1
    fi
    
    if sudo -u www-data pm2 list | grep -q "${PROJECT_NAME}"; then
        log_success "Application is running under PM2"
    else
        log_error "Application is not running"
        exit 1
    fi
    
    # Test HTTP response
    sleep 5
    if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200\|301\|302"; then
        log_success "Application responding to HTTP requests"
    else
        log_warning "Application may not be responding correctly"
    fi
    
    log_success "Deployment verification completed"
}

# Main deployment function
main() {
    echo "================================================================"
    echo "    Crypto Airdrop Platform - Production Setup"
    echo "================================================================"
    
    check_root
    install_system_dependencies
    install_nodejs
    setup_postgresql
    setup_application
    build_application
    setup_environment
    setup_database_schema
    setup_pm2
    setup_nginx
    setup_firewall
    setup_security
    verify_deployment
    
    echo ""
    echo "================================================================"
    log_success "🎉 Production deployment completed successfully!"
    echo "================================================================"
    echo ""
    echo "Application Details:"
    echo "• URL: http://${DOMAIN}"
    echo "• SSL: Run 'certbot --nginx -d ${DOMAIN}' for HTTPS"
    echo "• Process Manager: PM2"
    echo "• Web Server: Nginx"
    echo ""
    echo "Database Credentials:"
    echo "• Host: localhost"
    echo "• Database: ${DB_NAME}"
    echo "• Username: ${DB_USER}"
    echo "• Password: ${DB_PASSWORD}"
    echo ""
    echo "Management Commands:"
    echo "• View logs: sudo -u www-data pm2 logs ${PROJECT_NAME}"
    echo "• Restart app: sudo -u www-data pm2 restart ${PROJECT_NAME}"
    echo "• Check status: sudo -u www-data pm2 status"
    echo "• Reload Nginx: systemctl reload nginx"
    echo ""
    echo "Default Admin Account:"
    echo "• Username: admin"
    echo "• Password: admin123"
    echo ""
    log_warning "IMPORTANT: Change the default admin password immediately!"
    echo ""
}

# Run main function
main "$@"