#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

class PreflightChecker {
  constructor() {
    this.errors = [];
    this.warnings = [];
    this.passed = [];
  }

  log(message, type = 'info') {
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    const icons = {
      info: 'ℹ',
      success: '✓',
      warning: '⚠',
      error: '✗'
    };

    console.log(`${colors[type]}${icons[type]} ${message}${colors.reset}`);
  }

  checkNodeVersion() {
    try {
      const version = process.version;
      const majorVersion = parseInt(version.split('.')[0].slice(1));
      
      if (majorVersion >= 18) {
        this.passed.push(`Node.js version ${version} (compatible)`);
      } else {
        this.errors.push(`Node.js version ${version} is too old. Requires v18+`);
      }
    } catch (error) {
      this.errors.push('Node.js not found or version check failed');
    }
  }

  checkNpmVersion() {
    try {
      const npmVersion = execSync('npm --version', { encoding: 'utf8' }).trim();
      this.passed.push(`npm version ${npmVersion}`);
    } catch (error) {
      this.errors.push('npm not found or version check failed');
    }
  }

  checkRequiredFiles() {
    const requiredFiles = [
      'package.json',
      'server/index.ts',
      'client/src/App.tsx',
      'shared/schema.ts',
      'drizzle.config.ts',
      'vite.config.ts',
      'tailwind.config.ts',
      'tsconfig.json'
    ];

    requiredFiles.forEach(file => {
      if (fs.existsSync(file)) {
        this.passed.push(`Found ${file}`);
      } else {
        this.errors.push(`Missing required file: ${file}`);
      }
    });
  }

  checkPackageJson() {
    try {
      const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
      
      const requiredScripts = ['dev', 'build', 'start', 'db:push', 'db:seed'];
      requiredScripts.forEach(script => {
        if (packageJson.scripts && packageJson.scripts[script]) {
          this.passed.push(`Package script: ${script}`);
        } else {
          this.errors.push(`Missing package script: ${script}`);
        }
      });

      const requiredDeps = ['express', 'drizzle-orm', 'react', 'vite', 'typescript'];
      requiredDeps.forEach(dep => {
        if (packageJson.dependencies?.[dep] || packageJson.devDependencies?.[dep]) {
          this.passed.push(`Dependency: ${dep}`);
        } else {
          this.warnings.push(`Missing dependency: ${dep}`);
        }
      });

    } catch (error) {
      this.errors.push('Failed to parse package.json');
    }
  }

  checkEnvironmentSetup() {
    const envVars = ['DATABASE_URL', 'NODE_ENV'];
    
    envVars.forEach(envVar => {
      if (process.env[envVar]) {
        this.passed.push(`Environment variable: ${envVar}`);
      } else {
        if (envVar === 'DATABASE_URL') {
          this.errors.push(`Missing critical environment variable: ${envVar}`);
        } else {
          this.warnings.push(`Missing environment variable: ${envVar}`);
        }
      }
    });
  }

  checkDatabaseConnection() {
    if (!process.env.DATABASE_URL) {
      this.errors.push('DATABASE_URL not set - cannot test database connection');
      return;
    }

    try {
      // Test database configuration exists
      if (fs.existsSync('db/index.ts')) {
        this.passed.push('Database configuration file found');
      } else {
        this.errors.push('Database configuration file missing');
      }
    } catch (error) {
      this.errors.push(`Database setup check failed: ${error.message}`);
    }
  }

  checkTypeScript() {
    try {
      execSync('npx tsc --noEmit --skipLibCheck', { stdio: 'pipe', timeout: 10000 });
      this.passed.push('TypeScript compilation check passed');
    } catch (error) {
      if (error.signal === 'SIGTERM') {
        this.warnings.push('TypeScript check timed out - skipping');
      } else {
        this.warnings.push('TypeScript compilation has warnings or errors');
      }
    }
  }

  checkProductionReadiness() {
    // Check for production-specific requirements
    const prodChecks = [
      { file: '.env.production', required: false },
      { file: 'dist', required: false, type: 'directory' }
    ];

    prodChecks.forEach(check => {
      const exists = fs.existsSync(check.file);
      if (exists) {
        this.passed.push(`Production file: ${check.file}`);
      } else if (check.required) {
        this.errors.push(`Missing production file: ${check.file}`);
      } else {
        this.warnings.push(`Optional production file not found: ${check.file}`);
      }
    });
  }

  async run() {
    this.log('🚀 Starting Production Readiness Check', 'info');
    console.log('');

    this.log('Checking Node.js environment...', 'info');
    this.checkNodeVersion();
    this.checkNpmVersion();

    this.log('Checking project structure...', 'info');
    this.checkRequiredFiles();
    this.checkPackageJson();

    this.log('Checking environment configuration...', 'info');
    this.checkEnvironmentSetup();
    this.checkDatabaseConnection();

    this.log('Checking production readiness...', 'info');
    this.checkProductionReadiness();

    console.log('\n' + '='.repeat(60));
    this.log('PREFLIGHT CHECK RESULTS', 'info');
    console.log('='.repeat(60));

    if (this.passed.length > 0) {
      this.log(`\nPASSED (${this.passed.length}):`, 'success');
      this.passed.forEach(item => this.log(`  ${item}`, 'success'));
    }

    if (this.warnings.length > 0) {
      this.log(`\nWARNINGS (${this.warnings.length}):`, 'warning');
      this.warnings.forEach(item => this.log(`  ${item}`, 'warning'));
    }

    if (this.errors.length > 0) {
      this.log(`\nERRORS (${this.errors.length}):`, 'error');
      this.errors.forEach(item => this.log(`  ${item}`, 'error'));
      console.log('');
      this.log('❌ Production deployment blocked by errors above', 'error');
      process.exit(1);
    } else {
      console.log('');
      this.log('✅ All checks passed! Ready for production deployment', 'success');
      if (this.warnings.length > 0) {
        this.log('Note: Address warnings before deployment if possible', 'warning');
      }
      process.exit(0);
    }
  }
}

// Run the checker
const checker = new PreflightChecker();
checker.run().catch(error => {
  console.error('Preflight check failed:', error);
  process.exit(1);
});