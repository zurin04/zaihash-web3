#!/bin/bash

# One-Click Production Deployment Script
# Handles everything from system setup to running application
set -e

# Colors and logging
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

PROJECT_NAME="crypto-airdrop"
APP_DIR="/var/www/${PROJECT_NAME}"
DB_NAME="crypto_airdrop_db"
DB_USER="crypto_user"
DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
DOMAIN=${DOMAIN:-$(hostname -I | awk '{print $1}')}
NODE_VERSION="20"

# Enhanced logging
log() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

# Progress tracking
show_progress() {
    local current=$1
    local total=$2
    local desc=$3
    local percent=$((current * 100 / total))
    echo -e "\n${BLUE}[Step $current/$total - $percent%]${NC} $desc"
}

# Pre-flight checks
preflight_check() {
    log "Running pre-flight checks..."
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        error "This script must be run as root (use sudo)"
    fi
    
    # Check OS compatibility
    if ! command -v apt-get >/dev/null 2>&1; then
        error "This script requires Ubuntu/Debian with apt-get"
    fi
    
    # Check internet connectivity
    if ! ping -c 1 google.com >/dev/null 2>&1; then
        error "No internet connection detected"
    fi
    
    # Check available disk space (minimum 2GB)
    available_space=$(df / | tail -1 | awk '{print $4}')
    if [ "$available_space" -lt 2097152 ]; then
        error "Insufficient disk space. Need at least 2GB free"
    fi
    
    success "Pre-flight checks passed"
}

# System preparation
prepare_system() {
    show_progress 1 12 "Preparing system"
    
    log "Updating system packages..."
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq
    apt-get upgrade -y -qq
    
    log "Installing base dependencies..."
    apt-get install -y -qq \
        curl wget gnupg2 software-properties-common apt-transport-https \
        ca-certificates build-essential git ufw fail2ban nginx \
        certbot python3-certbot-nginx unzip
    
    success "System prepared"
}

# Install Node.js with error handling
install_nodejs() {
    show_progress 2 12 "Installing Node.js"
    
    # Clean up any existing Node.js
    apt-get remove -y -qq nodejs npm >/dev/null 2>&1 || true
    apt-get autoremove -y -qq >/dev/null 2>&1 || true
    
    # Install Node.js 20
    log "Adding NodeSource repository..."
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash - >/dev/null 2>&1
    
    log "Installing Node.js..."
    apt-get install -y -qq nodejs
    
    # Update npm
    npm install -g npm@latest >/dev/null 2>&1
    
    # Verify installation
    if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
        error "Node.js installation failed"
    fi
    
    NODE_VER=$(node --version)
    NPM_VER=$(npm --version)
    success "Node.js $NODE_VER and npm $NPM_VER installed"
}

# Install PostgreSQL with robust setup
install_postgresql() {
    show_progress 3 12 "Installing PostgreSQL"
    
    log "Installing PostgreSQL..."
    apt-get install -y -qq postgresql postgresql-contrib
    
    # Start PostgreSQL
    systemctl start postgresql
    systemctl enable postgresql
    
    # Wait for PostgreSQL to be ready
    sleep 3
    
    log "Creating database and user..."
    sudo -u postgres psql <<EOF >/dev/null 2>&1
DROP DATABASE IF EXISTS ${DB_NAME};
DROP USER IF EXISTS ${DB_USER};
CREATE DATABASE ${DB_NAME};
CREATE USER ${DB_USER} WITH ENCRYPTED PASSWORD '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
ALTER DATABASE ${DB_NAME} OWNER TO ${DB_USER};
GRANT ALL ON SCHEMA public TO ${DB_USER};
EOF
    
    success "PostgreSQL configured with database: $DB_NAME"
}

# Setup application directory
setup_app_directory() {
    show_progress 4 12 "Setting up application"
    
    log "Creating application directory..."
    mkdir -p ${APP_DIR}
    
    # Copy files if not already in target directory
    if [[ $(pwd) != ${APP_DIR} ]]; then
        log "Copying application files..."
        cp -r . ${APP_DIR}/
    fi
    
    cd ${APP_DIR}
    
    # Create www-data user if needed
    if ! id "www-data" >/dev/null 2>&1; then
        useradd -r -s /bin/false www-data
    fi
    
    # Clean any existing npm cache and config to prevent permission issues
    rm -rf /root/.npm /var/www/.npm /var/www/.npmrc /root/.npmrc
    
    # Create necessary directories with proper permissions
    mkdir -p /var/www/.npm /var/www/.config ${APP_DIR}/public/uploads
    
    # Set proper ownership and permissions
    chown -R www-data:www-data ${APP_DIR} /var/www/.npm /var/www/.config
    chmod -R 755 /var/www/.npm /var/www/.config
    
    success "Application directory configured"
}

# Install dependencies with enhanced error handling
install_dependencies() {
    show_progress 5 12 "Installing dependencies"
    
    cd ${APP_DIR}
    
    # Fix npm permissions and configuration
    log "Fixing npm permissions and configuration..."
    
    # Remove any existing npm config and cache
    rm -rf /root/.npm /var/www/.npm /var/www/.npmrc /root/.npmrc
    
    # Ensure /var/www directory has proper ownership
    chown -R www-data:www-data /var/www
    
    # Recreate npm directories with proper ownership
    mkdir -p /var/www/.npm /var/www/.config
    chown -R www-data:www-data /var/www/.npm /var/www/.config
    chmod -R 755 /var/www/.npm /var/www/.config
    
    # Create a home directory for www-data if it doesn't exist
    if [ ! -d "/var/www" ]; then
        mkdir -p /var/www
    fi
    chown www-data:www-data /var/www
    
    # Configure npm for www-data user with HOME set correctly
    sudo -u www-data HOME=/var/www npm config set cache /var/www/.npm
    sudo -u www-data HOME=/var/www npm config set prefix /var/www/.npm/global
    sudo -u www-data HOME=/var/www npm config set init-author-name "www-data"
    sudo -u www-data HOME=/var/www npm config set unsafe-perm true
    
    # Clean previous installations
    rm -rf node_modules package-lock.json .npm
    
    log "Installing Node.js packages..."
    
    # Install with retries
    local attempts=0
    local max_attempts=3
    
    while [ $attempts -lt $max_attempts ]; do
        if sudo -u www-data HOME=/var/www npm install --no-audit --no-fund --loglevel=error; then
            break
        fi
        
        attempts=$((attempts + 1))
        warning "Install attempt $attempts failed, retrying..."
        
        if [ $attempts -lt $max_attempts ]; then
            # Clean up and fix permissions on retry
            rm -rf node_modules package-lock.json .npm
            rm -rf /var/www/.npm
            mkdir -p /var/www/.npm
            chown -R www-data:www-data /var/www/.npm
            chmod -R 755 /var/www/.npm
            sudo -u www-data HOME=/var/www npm config set cache /var/www/.npm
            sleep 5
        else
            warning "Standard npm install failed, trying alternative approach..."
            # Fallback: install as root and then fix permissions
            if npm install --no-audit --no-fund --loglevel=error; then
                chown -R www-data:www-data node_modules package-lock.json
                success "Dependencies installed using fallback method"
                break
            else
                error "Failed to install dependencies after $max_attempts attempts with both methods"
            fi
        fi
    done
    
    success "Dependencies installed"
}

# Build application
build_application() {
    show_progress 6 12 "Building application"
    
    cd ${APP_DIR}
    
    log "Building frontend and backend..."
    
    # Build with error handling
    if ! sudo -u www-data npm run build; then
        error "Build failed"
    fi
    
    # Verify build output
    if [ ! -d "dist" ]; then
        error "Build output not found"
    fi
    
    # Clean development dependencies
    log "Cleaning development dependencies..."
    sudo -u www-data npm prune --production --no-audit --no-fund
    
    success "Application built successfully"
}

# Setup environment
setup_environment() {
    show_progress 7 12 "Configuring environment"
    
    cd ${APP_DIR}
    
    # Create production environment file
    cat > .env.production <<EOF
NODE_ENV=production
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
SESSION_SECRET=$(openssl rand -base64 64)
PORT=5000
DOMAIN=${DOMAIN}
EOF
    
    chown www-data:www-data .env.production
    chmod 600 .env.production
    
    success "Environment configured"
}

# Setup database schema
setup_database() {
    show_progress 8 12 "Setting up database schema"
    
    cd ${APP_DIR}
    
    log "Pushing database schema..."
    if ! sudo -u www-data npm run db:push; then
        warning "Schema push failed, trying alternative method..."
        # Alternative: direct schema creation if needed
        error "Database schema setup failed"
    fi
    
    log "Seeding database..."
    if ! sudo -u www-data npm run db:seed; then
        warning "Database seeding failed, continuing with empty database"
    fi
    
    success "Database schema configured"
}

# Install and configure PM2
setup_pm2() {
    show_progress 9 12 "Setting up process manager"
    
    log "Installing PM2..."
    npm install -g pm2@latest >/dev/null 2>&1
    
    cd ${APP_DIR}
    
    # Create PM2 ecosystem
    cat > ecosystem.config.js <<EOF
module.exports = {
  apps: [{
    name: '${PROJECT_NAME}',
    script: 'npm',
    args: 'start',
    cwd: '${APP_DIR}',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/pm2/${PROJECT_NAME}-error.log',
    out_file: '/var/log/pm2/${PROJECT_NAME}-out.log',
    log_file: '/var/log/pm2/${PROJECT_NAME}.log',
    time: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s'
  }]
}
EOF
    
    # Create log directory
    mkdir -p /var/log/pm2
    chown -R www-data:www-data /var/log/pm2
    
    # Start application
    log "Starting application..."
    sudo -u www-data pm2 start ecosystem.config.js
    sudo -u www-data pm2 save
    
    # Setup startup script
    env PATH=$PATH:/usr/bin pm2 startup systemd -u www-data --hp /var/www >/dev/null 2>&1
    
    success "Process manager configured"
}

# Configure Nginx
setup_nginx() {
    show_progress 10 12 "Configuring web server"
    
    # Create Nginx configuration
    cat > /etc/nginx/sites-available/${PROJECT_NAME} <<EOF
server {
    listen 80;
    server_name ${DOMAIN};
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
    
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    location /uploads/ {
        alias ${APP_DIR}/public/uploads/;
        expires 1M;
        add_header Cache-Control "public, immutable";
    }
}
EOF
    
    # Enable site
    ln -sf /etc/nginx/sites-available/${PROJECT_NAME} /etc/nginx/sites-enabled/
    rm -f /etc/nginx/sites-enabled/default
    
    # Test and restart Nginx
    if ! nginx -t; then
        error "Nginx configuration invalid"
    fi
    
    systemctl restart nginx
    systemctl enable nginx
    
    success "Web server configured"
}

# Setup security
setup_security() {
    show_progress 11 12 "Configuring security"
    
    log "Setting up firewall..."
    ufw --force reset >/dev/null 2>&1
    ufw default deny incoming >/dev/null 2>&1
    ufw default allow outgoing >/dev/null 2>&1
    ufw allow ssh >/dev/null 2>&1
    ufw allow 80/tcp >/dev/null 2>&1
    ufw allow 443/tcp >/dev/null 2>&1
    ufw --force enable >/dev/null 2>&1
    
    log "Configuring fail2ban..."
    cat > /etc/fail2ban/jail.local <<EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[nginx-http-auth]
enabled = true

[nginx-noscript]
enabled = true
EOF
    
    systemctl restart fail2ban >/dev/null 2>&1
    systemctl enable fail2ban >/dev/null 2>&1
    
    success "Security configured"
}

# Final verification
verify_deployment() {
    show_progress 12 12 "Verifying deployment"
    
    log "Checking services..."
    
    # Check PostgreSQL
    if ! systemctl is-active --quiet postgresql; then
        error "PostgreSQL is not running"
    fi
    
    # Check Nginx
    if ! systemctl is-active --quiet nginx; then
        error "Nginx is not running"
    fi
    
    # Check application
    if ! sudo -u www-data pm2 list | grep -q "${PROJECT_NAME}"; then
        error "Application is not running"
    fi
    
    # Test HTTP response
    sleep 5
    if ! curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200\|301\|302"; then
        warning "Application may not be responding correctly"
    fi
    
    success "All services verified"
}

# Save deployment info
save_deployment_info() {
    cat > /root/deployment-info.txt <<EOF
Crypto Airdrop Platform - Deployment Info
=========================================
Date: $(date)
Domain: ${DOMAIN}
Application: http://${DOMAIN}

Database Credentials:
- Host: localhost
- Database: ${DB_NAME}
- Username: ${DB_USER}
- Password: ${DB_PASSWORD}

Default Admin:
- Username: admin
- Password: admin123

Management Commands:
- View logs: sudo -u www-data pm2 logs ${PROJECT_NAME}
- Restart app: sudo -u www-data pm2 restart ${PROJECT_NAME}
- Check status: sudo -u www-data pm2 status
- Reload Nginx: systemctl reload nginx

Important: Change default admin password immediately!
SSL Setup: certbot --nginx -d ${DOMAIN}
EOF
    
    chmod 600 /root/deployment-info.txt
}

# Main execution
main() {
    clear
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                    Crypto Airdrop Platform                                  ║"
    echo "║                    One-Click Production Setup                               ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo ""
    
    preflight_check
    prepare_system
    install_nodejs
    install_postgresql
    setup_app_directory
    install_dependencies
    build_application
    setup_environment
    setup_database
    setup_pm2
    setup_nginx
    setup_security
    verify_deployment
    save_deployment_info
    
    echo ""
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                         🎉 DEPLOYMENT COMPLETE! 🎉                         ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo ""
    success "Your crypto airdrop platform is now live!"
    echo ""
    echo "📍 Access your application:"
    echo "   URL: http://${DOMAIN}"
    echo ""
    echo "🔐 Default login:"
    echo "   Username: admin"
    echo "   Password: admin123"
    echo ""
    echo "📊 Database credentials:"
    echo "   Host: localhost"
    echo "   Database: ${DB_NAME}"
    echo "   Username: ${DB_USER}"
    echo "   Password: ${DB_PASSWORD}"
    echo ""
    echo "🛠️  Management commands:"
    echo "   View logs: sudo -u www-data pm2 logs ${PROJECT_NAME}"
    echo "   Restart: sudo -u www-data pm2 restart ${PROJECT_NAME}"
    echo ""
    echo "🔒 Security setup:"
    echo "   1. Change admin password immediately"
    echo "   2. Setup SSL: certbot --nginx -d ${DOMAIN}"
    echo ""
    echo "📄 Full deployment info saved to: /root/deployment-info.txt"
    echo ""
    warning "IMPORTANT: Change the default admin password now!"
}

# Execute with error handling
trap 'error "Deployment failed at line $LINENO"' ERR
main "$@"