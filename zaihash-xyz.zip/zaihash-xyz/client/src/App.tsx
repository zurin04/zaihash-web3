import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { GlobalChatProvider } from "@/hooks/use-global-chat";

// Components
import HomePage from "@/pages/home-page";
import AirdropsPage from "@/pages/airdrops-page";
import AirdropDetails from "@/pages/airdrop-details";
import ChatPage from "@/pages/chat-page";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import ProfilePage from "@/pages/profile-page";
import CreateAirdropPage from "@/pages/create-airdrop";
import MembersPage from "@/pages/members-page";

// Legal Pages
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/terms-of-service";
import CookiePolicy from "@/pages/cookie-policy";
import Disclaimer from "@/pages/disclaimer";

// Admin Pages
import AdminDashboardPage from "@/pages/admin/dashboard";
import AdminCreateAirdropPage from "@/pages/admin/create-airdrop";
import EditAirdropPage from "@/pages/admin/edit-airdrop";
import CreatorApplicationsPage from "@/pages/admin/creator-applications";

// Protected Routes
import { ProtectedRoute } from "@/lib/protected-route";
import { AdminRoute } from "@/lib/admin-route";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/airdrops" component={AirdropsPage} />
      <Route path="/airdrops/category/:categoryId" component={AirdropsPage} />
      <Route path="/airdrop/:id" component={AirdropDetails} />
      <Route path="/chat" component={ChatPage} />
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/profile" component={() => <ProfilePage />} />
      <ProtectedRoute path="/create-airdrop" component={() => <CreateAirdropPage />} />
      
      {/* Admin Routes */}
      <AdminRoute path="/admin" component={() => <AdminDashboardPage />} />
      <AdminRoute path="/admin/airdrops/create" component={() => <AdminCreateAirdropPage />} />
      <AdminRoute path="/admin/airdrops/edit/:id" component={() => <EditAirdropPage />} />
      <AdminRoute path="/admin/creator-applications" component={() => <CreatorApplicationsPage />} />
      <AdminRoute path="/admin/members" component={() => <MembersPage />} />
      
      {/* Legal Pages */}
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/terms-of-service" component={TermsOfService} />
      <Route path="/cookie-policy" component={CookiePolicy} />
      <Route path="/disclaimer" component={Disclaimer} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <GlobalChatProvider>
          <Router />
          <Toaster />
        </GlobalChatProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
