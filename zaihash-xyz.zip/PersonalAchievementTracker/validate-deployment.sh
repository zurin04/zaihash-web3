#!/bin/bash

# Deployment Validation Script
# Tests the deployment setup before going to production

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_test() {
    echo -e "${YELLOW}[TEST]${NC} $1"
}

print_pass() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

print_fail() {
    echo -e "${RED}[FAIL]${NC} $1"
}

# Test 1: Check if all required files exist
print_test "Checking required files..."
required_files=("package.json" "server/index.ts" "db/index.ts" "shared/schema.ts" "deploy.sh")
for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        print_pass "Found $file"
    else
        print_fail "Missing $file"
        exit 1
    fi
done

# Test 2: Check Node.js version
print_test "Checking Node.js version..."
if command -v node >/dev/null 2>&1; then
    node_version=$(node --version)
    print_pass "Node.js version: $node_version"
else
    print_fail "Node.js not found"
    exit 1
fi

# Test 3: Check npm dependencies
print_test "Checking npm dependencies..."
if [ -f "package-lock.json" ]; then
    print_pass "package-lock.json exists"
else
    print_fail "package-lock.json missing - run 'npm install' first"
    exit 1
fi

# Test 4: Check database requirements
print_test "Checking database setup..."
if command -v psql >/dev/null 2>&1; then
    print_pass "PostgreSQL client available"
    
    # Check if we can connect to postgres (indicates PostgreSQL is installed)
    if sudo -u postgres psql -c "SELECT 1;" > /dev/null 2>&1; then
        print_pass "PostgreSQL server is running"
    else
        print_fail "PostgreSQL server not running or not installed"
        echo "  Install with: sudo apt install -y postgresql postgresql-contrib"
        echo "  Or run: sudo ./setup-database.sh"
        exit 1
    fi
else
    print_fail "PostgreSQL not found"
    echo "  Install with: sudo apt install -y postgresql postgresql-contrib"
    exit 1
fi

# Test 5: Check if build dependencies exist
print_test "Checking build dependencies..."
if command -v npm >/dev/null 2>&1 && [ -f "vite.config.ts" ]; then
    print_pass "Build tools available"
else
    print_fail "Build tools missing"
    exit 1
fi

# Test 6: Check TypeScript files exist
print_test "Checking TypeScript configuration..."
if [ -f "tsconfig.json" ]; then
    print_pass "TypeScript configuration found"
else
    print_fail "TypeScript configuration missing"
    exit 1
fi

# Test 7: Check database schema file
print_test "Checking database schema..."
if [ -f "shared/schema.ts" ] && [ -f "drizzle.config.ts" ]; then
    print_pass "Database schema files found"
else
    print_fail "Database schema files missing"
    exit 1
fi

echo ""
print_pass "All validation tests passed! Deployment is ready."
echo ""
echo "Next steps:"
echo "1. Run: sudo ./deploy.sh"
echo "2. Access your application at http://your-domain.com"
echo "3. Login with admin/admin123 and change password"