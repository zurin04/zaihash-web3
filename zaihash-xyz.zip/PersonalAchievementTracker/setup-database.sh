#!/bin/bash

# Database Setup Script
# Creates PostgreSQL database for the crypto airdrop platform

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
DB_NAME="crypto_airdrop_db"
DB_USER="crypto_user"
DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

check_postgres() {
    if ! command -v psql >/dev/null 2>&1; then
        print_error "PostgreSQL is not installed. Install it first:"
        echo "sudo apt update"
        echo "sudo apt install -y postgresql postgresql-contrib"
        exit 1
    fi
}

setup_database() {
    print_status "Setting up PostgreSQL database..."
    
    # Start PostgreSQL if not running
    sudo systemctl start postgresql || true
    sudo systemctl enable postgresql || true
    
    # Wait for PostgreSQL
    print_status "Waiting for PostgreSQL to be ready..."
    for i in {1..30}; do
        if sudo -u postgres psql -c "SELECT 1;" > /dev/null 2>&1; then
            break
        fi
        sleep 2
    done
    
    # Drop existing if requested
    if [ "$1" = "--reset" ]; then
        print_warning "Resetting database (dropping existing data)..."
        sudo -u postgres psql -c "DROP DATABASE IF EXISTS ${DB_NAME};" || true
        sudo -u postgres psql -c "DROP USER IF EXISTS ${DB_USER};" || true
    fi
    
    # Create user if not exists
    print_status "Creating database user..."
    sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';" 2>/dev/null || {
        print_warning "User ${DB_USER} already exists, updating password..."
        sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';"
    }
    
    # Create database if not exists
    print_status "Creating database..."
    sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};" 2>/dev/null || {
        print_warning "Database ${DB_NAME} already exists"
    }
    
    # Set permissions
    print_status "Setting database permissions..."
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"
    sudo -u postgres psql -d ${DB_NAME} -c "GRANT ALL ON SCHEMA public TO ${DB_USER};"
    sudo -u postgres psql -d ${DB_NAME} -c "GRANT ALL ON ALL TABLES IN SCHEMA public TO ${DB_USER};"
    sudo -u postgres psql -d ${DB_NAME} -c "GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO ${DB_USER};"
    sudo -u postgres psql -d ${DB_NAME} -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO ${DB_USER};"
    sudo -u postgres psql -d ${DB_NAME} -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO ${DB_USER};"
    
    print_success "Database created successfully"
}

setup_environment() {
    print_status "Creating environment configuration..."
    
    # Create .env file
    cat > .env << EOF
NODE_ENV=development
PORT=5000
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
PGHOST=localhost
PGPORT=5432
PGUSER=${DB_USER}
PGPASSWORD=${DB_PASSWORD}
PGDATABASE=${DB_NAME}
SESSION_SECRET=$(openssl rand -base64 32)
EOF
    
    print_success "Environment file created"
}

apply_schema() {
    print_status "Applying database schema..."
    
    # Export environment variables
    export DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}"
    
    # Apply schema
    if [ -f "package.json" ]; then
        npm run db:push || {
            print_error "Failed to apply schema. Make sure you're in the project directory."
            exit 1
        }
        print_success "Database schema applied"
        
        # Seed database
        print_status "Seeding database..."
        npm run db:seed && print_success "Database seeded successfully" || print_warning "Seeding failed, but database is ready"
    else
        print_warning "package.json not found. Run this script from your project directory."
        print_warning "You'll need to run 'npm run db:push' and 'npm run db:seed' manually."
    fi
}

test_connection() {
    print_status "Testing database connection..."
    
    if PGPASSWORD="${DB_PASSWORD}" psql -h localhost -U ${DB_USER} -d ${DB_NAME} -c "SELECT 1;" > /dev/null 2>&1; then
        print_success "Database connection successful"
    else
        print_error "Database connection failed"
        exit 1
    fi
}

show_credentials() {
    echo ""
    print_success "Database setup completed!"
    echo "================================"
    echo "Database Credentials:"
    echo "• Host: localhost"
    echo "• Port: 5432"
    echo "• Database: ${DB_NAME}"
    echo "• Username: ${DB_USER}"
    echo "• Password: ${DB_PASSWORD}"
    echo ""
    echo "Database URL:"
    echo "postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}"
    echo ""
    echo "Connection Commands:"
    echo "• Connect: PGPASSWORD='${DB_PASSWORD}' psql -h localhost -U ${DB_USER} -d ${DB_NAME}"
    echo "• Admin: sudo -u postgres psql -d ${DB_NAME}"
    echo ""
    print_warning "Save these credentials - they are needed for your application!"
}

main() {
    echo "Crypto Airdrop Platform - Database Setup"
    echo "========================================"
    
    if [ "$1" = "--help" ]; then
        echo "Usage:"
        echo "  $0           # Create database and user"
        echo "  $0 --reset   # Reset database (delete all data)"
        echo "  $0 --help    # Show this help"
        exit 0
    fi
    
    check_postgres
    setup_database "$1"
    setup_environment
    test_connection
    apply_schema
    show_credentials
}

main "$@"