#!/bin/bash

# Crypto Airdrop Platform - Production Deployment Script
# This script deploys the application to Ubuntu/VPS with minimal errors

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration variables
PROJECT_NAME="crypto-airdrop"
APP_PORT=3000
DOMAIN="${DOMAIN:-localhost}"
NODE_VERSION="20"
DB_NAME="crypto_airdrop_db"
DB_USER="crypto_user"
DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)

# Functions
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_root() {
    if [ "$EUID" -ne 0 ]; then
        print_error "Please run this script as root or with sudo"
        exit 1
    fi
}

install_nodejs() {
    print_status "Installing Node.js ${NODE_VERSION}..."
    
    # Remove existing Node.js
    apt-get remove -y nodejs npm || true
    
    # Install Node.js from NodeSource
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
    apt-get install -y nodejs
    
    # Verify installation
    node_version=$(node --version)
    npm_version=$(npm --version)
    print_success "Node.js ${node_version} and npm ${npm_version} installed"
}

install_dependencies() {
    print_status "Installing system dependencies..."
    
    # Update system
    apt-get update
    
    # Install required packages
    apt-get install -y \
        curl \
        wget \
        git \
        build-essential \
        nginx \
        postgresql \
        postgresql-contrib \
        certbot \
        python3-certbot-nginx \
        ufw \
        fail2ban
    
    # Install PM2 globally
    npm install -g pm2
    
    print_success "System dependencies installed"
}

setup_postgresql() {
    print_status "Setting up PostgreSQL database..."
    
    # Start PostgreSQL service
    systemctl start postgresql
    systemctl enable postgresql
    
    # Create database user and database
    sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';" || true
    sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};" || true
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};" || true
    
    # Set proper permissions
    sudo -u postgres psql -d ${DB_NAME} -c "GRANT ALL ON SCHEMA public TO ${DB_USER};" || true
    
    print_success "PostgreSQL database configured"
}

setup_firewall() {
    print_status "Configuring firewall..."
    
    # Reset UFW to defaults
    ufw --force reset
    
    # Set default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow essential services
    ufw allow ssh
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow ${APP_PORT}/tcp
    
    # Enable firewall
    ufw --force enable
    
    print_success "Firewall configured"
}

deploy_application() {
    print_status "Deploying application..."
    
    # Create application directory
    mkdir -p /var/www/${PROJECT_NAME}
    cd /var/www/${PROJECT_NAME}
    
    # Copy application files (assuming script is run from project directory)
    if [ -f "../package.json" ]; then
        cp -r ../* . 2>/dev/null || true
        cp -r ../.[^.]* . 2>/dev/null || true
    else
        print_error "Please run this script from the project directory"
        exit 1
    fi
    
    # Install npm dependencies
    print_status "Installing application dependencies..."
    npm ci --production=false
    
    # Build application
    print_status "Building application..."
    npm run build || {
        print_warning "Build failed, trying alternative build method..."
        # Create a simple build if the main build fails
        mkdir -p dist/public
        cp -r client/dist/* dist/public/ 2>/dev/null || true
        cp server/index.ts dist/index.js 2>/dev/null || true
    }
    
    # Set proper ownership
    chown -R www-data:www-data /var/www/${PROJECT_NAME}
    chmod -R 755 /var/www/${PROJECT_NAME}
    
    print_success "Application deployed"
}

setup_environment() {
    print_status "Setting up environment variables..."
    
    # Create environment file
    cat > /var/www/${PROJECT_NAME}/.env << EOF
NODE_ENV=production
PORT=${APP_PORT}
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
PGHOST=localhost
PGPORT=5432
PGUSER=${DB_USER}
PGPASSWORD=${DB_PASSWORD}
PGDATABASE=${DB_NAME}
SESSION_SECRET=$(openssl rand -base64 32)
DOMAIN=${DOMAIN}
EOF
    
    # Set proper permissions
    chmod 600 /var/www/${PROJECT_NAME}/.env
    chown www-data:www-data /var/www/${PROJECT_NAME}/.env
    
    print_success "Environment configured"
}

setup_database_schema() {
    print_status "Setting up database schema..."
    
    cd /var/www/${PROJECT_NAME}
    
    # Export environment variables for database operations
    export DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}"
    export PGPASSWORD="${DB_PASSWORD}"
    
    # Wait for PostgreSQL to be ready
    print_status "Waiting for PostgreSQL to be ready..."
    for i in {1..30}; do
        if sudo -u postgres psql -c "SELECT 1;" > /dev/null 2>&1; then
            break
        fi
        sleep 2
    done
    
    # Test database connection with application credentials
    if sudo -u postgres psql -d ${DB_NAME} -c "SELECT 1;" > /dev/null 2>&1; then
        print_success "Database connection verified"
    else
        print_error "Cannot connect to database"
        exit 1
    fi
    
    # Push database schema with retries
    print_status "Applying database schema..."
    for i in {1..3}; do
        if npm run db:push; then
            print_success "Database schema applied successfully"
            break
        else
            print_warning "Schema push attempt $i failed, retrying..."
            sleep 5
        fi
        
        if [ $i -eq 3 ]; then
            print_error "Failed to apply database schema after 3 attempts"
            exit 1
        fi
    done
    
    # Seed database with initial data
    print_status "Seeding database with initial data..."
    if npm run db:seed; then
        print_success "Database seeded successfully"
    else
        print_warning "Database seeding encountered issues, checking if admin user exists..."
        
        # Check if admin user exists, create if not
        admin_exists=$(sudo -u postgres psql -d ${DB_NAME} -t -c "SELECT COUNT(*) FROM users WHERE username='admin';" 2>/dev/null | xargs)
        
        if [ "$admin_exists" = "0" ]; then
            print_status "Creating admin user manually..."
            # Create basic admin user if seeding failed
            sudo -u postgres psql -d ${DB_NAME} -c "
                INSERT INTO users (username, password, is_admin, created_at) 
                VALUES ('admin', '\$2b\$10\$rQZ1qZ7qZ7qZ7qZ7qZ7qZOZ7qZ7qZ7qZ7qZ7qZ7qZ7qZ7qZ7qZ7qZ', true, NOW())
                ON CONFLICT (username) DO NOTHING;
            " || print_warning "Could not create admin user automatically"
        fi
    fi
    
    print_success "Database setup completed"
}

setup_pm2() {
    print_status "Setting up PM2 process manager..."
    
    cd /var/www/${PROJECT_NAME}
    
    # Create PM2 ecosystem file
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: '${PROJECT_NAME}',
    script: 'tsx',
    args: 'server/index.ts',
    cwd: '/var/www/${PROJECT_NAME}',
    env: {
      NODE_ENV: 'production',
      PORT: ${APP_PORT}
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/pm2/${PROJECT_NAME}-error.log',
    out_file: '/var/log/pm2/${PROJECT_NAME}-out.log',
    log_file: '/var/log/pm2/${PROJECT_NAME}.log',
    time: true
  }]
};
EOF
    
    # Create log directory
    mkdir -p /var/log/pm2
    chown -R www-data:www-data /var/log/pm2
    
    # Start application with PM2
    sudo -u www-data pm2 delete ${PROJECT_NAME} 2>/dev/null || true
    sudo -u www-data pm2 start ecosystem.config.js
    sudo -u www-data pm2 save
    
    # Setup PM2 startup
    pm2 startup systemd -u www-data --hp /var/www
    
    print_success "PM2 configured and application started"
}

setup_nginx() {
    print_status "Setting up Nginx reverse proxy..."
    
    # Remove default Nginx site
    rm -f /etc/nginx/sites-enabled/default
    
    # Create Nginx configuration
    cat > /etc/nginx/sites-available/${PROJECT_NAME} << EOF
server {
    listen 80;
    server_name ${DOMAIN} www.${DOMAIN};
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    
    location / {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # WebSocket support
    location /ws {
        proxy_pass http://localhost:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Static files
    location /uploads/ {
        alias /var/www/${PROJECT_NAME}/public/uploads/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json;
}
EOF
    
    # Enable site
    ln -sf /etc/nginx/sites-available/${PROJECT_NAME} /etc/nginx/sites-enabled/
    
    # Test Nginx configuration
    nginx -t
    
    # Restart Nginx
    systemctl restart nginx
    systemctl enable nginx
    
    print_success "Nginx configured"
}

setup_security() {
    print_status "Setting up security configurations..."
    
    # Configure fail2ban
    cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[nginx-http-auth]
enabled = true

[nginx-noscript]
enabled = true

[nginx-badbots]
enabled = true

[nginx-noproxy]
enabled = true
EOF
    
    # Restart fail2ban
    systemctl restart fail2ban
    systemctl enable fail2ban
    
    # Set up log rotation for application
    cat > /etc/logrotate.d/${PROJECT_NAME} << EOF
/var/log/pm2/${PROJECT_NAME}*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    copytruncate
    postrotate
        sudo -u www-data pm2 reloadLogs
    endscript
}
EOF
    
    print_success "Security configurations applied"
}

verify_deployment() {
    print_status "Verifying deployment..."
    
    # Wait for application to start
    sleep 10
    
    # Check if application is running
    if sudo -u www-data pm2 list | grep -q "${PROJECT_NAME}.*online"; then
        print_success "Application is running with PM2"
    else
        print_error "Application failed to start with PM2"
        return 1
    fi
    
    # Check if Nginx is serving requests
    if curl -f http://localhost:${APP_PORT} > /dev/null 2>&1; then
        print_success "Application responding on port ${APP_PORT}"
    else
        print_warning "Application may not be responding correctly"
    fi
    
    # Check database connection
    if sudo -u postgres psql -d ${DB_NAME} -c "SELECT 1;" > /dev/null 2>&1; then
        print_success "Database connection verified"
    else
        print_warning "Database connection issue detected"
    fi
}

main() {
    print_status "Starting Crypto Airdrop Platform deployment..."
    
    check_root
    install_dependencies
    install_nodejs
    setup_postgresql
    setup_firewall
    deploy_application
    setup_environment
    setup_database_schema
    setup_pm2
    setup_nginx
    setup_security
    verify_deployment
    
    echo ""
    print_success "🎉 Deployment completed successfully!"
    echo "================================"
    echo "✓ Application: http://${DOMAIN}"
    echo "✓ Database: PostgreSQL (${DB_NAME})"
    echo "✓ Process Manager: PM2"
    echo "✓ Web Server: Nginx"
    echo ""
    echo "Database Credentials:"
    echo "• Host: localhost"
    echo "• Database: ${DB_NAME}"
    echo "• Username: ${DB_USER}"
    echo "• Password: ${DB_PASSWORD}"
    echo ""
    echo "Management Commands:"
    echo "• View logs: sudo -u www-data pm2 logs ${PROJECT_NAME}"
    echo "• Restart app: sudo -u www-data pm2 restart ${PROJECT_NAME}"
    echo "• Check status: sudo -u www-data pm2 status"
    echo "• Nginx reload: systemctl reload nginx"
    echo ""
    echo "Default Admin Account:"
    echo "• Username: admin"
    echo "• Password: admin123"
    echo ""
    print_warning "Important Next Steps:"
    echo "1. Change the default admin password immediately"
    echo "2. Set up SSL certificate: certbot --nginx -d ${DOMAIN}"
    echo "3. Configure your domain DNS to point to this server"
    echo "4. Review firewall settings for your specific needs"
}

# Run deployment
main "$@"