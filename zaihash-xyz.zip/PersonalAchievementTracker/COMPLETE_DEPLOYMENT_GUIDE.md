# Complete Deployment Guide

## Prerequisites

- Ubuntu 20.04+ or Debian 11+ server
- Root or sudo access
- At least 1GB RAM and 10GB storage
- Domain name (optional but recommended)

## Step 1: Prepare Your Server

### Upload Your Project
```bash
# Upload your project files to the server
scp -r /path/to/your/project root@your-server-ip:/root/crypto-airdrop
# OR clone from repository
git clone your-repository-url /root/crypto-airdrop
cd /root/crypto-airdrop
```

### Make Scripts Executable
```bash
chmod +x validate-deployment.sh deploy.sh
```

## Step 2: Validate Setup

Run the validation script to check everything is ready:

```bash
./validate-deployment.sh
```

**Expected Output:**
```
[PASS] Found package.json
[PASS] Found server/index.ts
[PASS] PostgreSQL server is running
[PASS] All validation tests passed! Deployment is ready.
```

### If Database Setup Fails

If you see database-related errors, you have two options:

**Option A: Let deployment script handle it (Recommended)**
```bash
# Continue with deployment - it will install and setup PostgreSQL
sudo ./deploy.sh
```

**Option B: Setup database manually first**
```bash
# Install PostgreSQL first
sudo apt update
sudo apt install -y postgresql postgresql-contrib

# Setup database for your project
sudo ./setup-database.sh

# Then run validation again
./validate-deployment.sh
```

## Step 3: Deploy to Production

Run the deployment script with root privileges:

```bash
sudo ./deploy.sh
```

### For Custom Domain
```bash
export DOMAIN=yourdomain.com
sudo ./deploy.sh
```

## What the Deployment Does

### System Installation
- Installs Node.js 20, PostgreSQL, Nginx, PM2
- Configures firewall (UFW) with secure settings
- Sets up fail2ban for intrusion prevention

### Database Setup
- Creates PostgreSQL database: `crypto_airdrop_db`
- Creates database user: `crypto_user` with secure password
- Applies your existing database schema automatically
- Seeds initial data (categories, admin user, sample airdrops)

### Application Deployment
- Builds your application for production
- Configures PM2 process manager
- Sets up Nginx reverse proxy with WebSocket support
- Configures SSL-ready setup

### Security Configuration
- Firewall: Only ports 22 (SSH), 80 (HTTP), 443 (HTTPS), 3000 (app) open
- Rate limiting: 10 requests/second via Nginx
- Log rotation for application logs
- Secure database with random passwords

## Step 4: Access Your Application

After successful deployment:

1. **Visit your application**: `http://your-domain-or-ip`
2. **Admin login**: Username `admin`, Password `admin123`
3. **Change password immediately** after first login

## Step 5: Set Up SSL (Recommended)

```bash
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

Follow the prompts to get a free SSL certificate.

## Database Management

### Database Credentials
The deployment creates these credentials (saved in deployment output):
- **Host**: localhost
- **Database**: crypto_airdrop_db
- **Username**: crypto_user
- **Password**: [auto-generated, shown during deployment]

### Access Database
```bash
# Connect to database
sudo -u postgres psql -d crypto_airdrop_db

# View tables
\dt

# Check users
SELECT id, username, is_admin, is_creator FROM users;

# Check airdrops
SELECT id, title, status FROM airdrops;
```

### Database Operations
```bash
# Backup database
sudo -u postgres pg_dump crypto_airdrop_db > backup.sql

# Restore database
sudo -u postgres psql crypto_airdrop_db < backup.sql

# Reset database (if needed)
cd /var/www/crypto-airdrop
npm run db:push
npm run db:seed
```

## Application Management

### PM2 Commands
```bash
# View application status
sudo -u www-data pm2 status

# View logs
sudo -u www-data pm2 logs crypto-airdrop

# Restart application
sudo -u www-data pm2 restart crypto-airdrop

# Stop application
sudo -u www-data pm2 stop crypto-airdrop

# Start application
sudo -u www-data pm2 start crypto-airdrop
```

### Nginx Commands
```bash
# Test configuration
sudo nginx -t

# Reload configuration
sudo systemctl reload nginx

# Restart Nginx
sudo systemctl restart nginx

# Check status
sudo systemctl status nginx
```

### Update Application
```bash
cd /var/www/crypto-airdrop

# Pull latest changes
git pull origin main

# Install dependencies
npm ci

# Build application
npm run build

# Update database schema
npm run db:push

# Restart application
sudo -u www-data pm2 restart crypto-airdrop
```

## Troubleshooting

### Application Won't Start
```bash
# Check logs
sudo -u www-data pm2 logs crypto-airdrop

# Check if port is in use
sudo lsof -i :3000

# Check disk space
df -h

# Check memory
free -h
```

### Database Issues
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Restart PostgreSQL
sudo systemctl restart postgresql

# Check database connection
sudo -u postgres psql -c "SELECT version();"

# Test application database connection
cd /var/www/crypto-airdrop
DATABASE_URL="postgresql://crypto_user:password@localhost:5432/crypto_airdrop_db" npm run db:push
```

### Nginx Issues
```bash
# Check Nginx status
sudo systemctl status nginx

# Check configuration
sudo nginx -t

# View error logs
sudo tail -f /var/log/nginx/error.log

# Check if port 80/443 is available
sudo netstat -tlnp | grep :80
sudo netstat -tlnp | grep :443
```

### SSL Certificate Issues
```bash
# Check certificate status
sudo certbot certificates

# Renew certificate
sudo certbot renew

# Test renewal
sudo certbot renew --dry-run
```

## File Locations

- **Application**: `/var/www/crypto-airdrop/`
- **Logs**: `/var/log/pm2/crypto-airdrop*.log`
- **Nginx Config**: `/etc/nginx/sites-available/crypto-airdrop`
- **Environment**: `/var/www/crypto-airdrop/.env`
- **SSL Certificates**: `/etc/letsencrypt/live/yourdomain.com/`

## Security Best Practices

### Change Default Passwords
1. Admin user password (via web interface)
2. Database password (if needed for external access)
3. SSH keys instead of password authentication

### Regular Maintenance
```bash
# Update system packages
sudo apt update && sudo apt upgrade

# Update Node.js packages
cd /var/www/crypto-airdrop
npm audit
npm update

# Check logs regularly
sudo -u www-data pm2 logs crypto-airdrop --lines 100

# Monitor disk space
df -h
```

### Backup Strategy
```bash
# Daily database backup
sudo -u postgres pg_dump crypto_airdrop_db > /backup/db-$(date +%Y%m%d).sql

# Weekly application backup
tar -czf /backup/app-$(date +%Y%m%d).tar.gz /var/www/crypto-airdrop
```

## Support

If you encounter issues:

1. Check the troubleshooting section above
2. Review application logs: `sudo -u www-data pm2 logs crypto-airdrop`
3. Check system logs: `sudo journalctl -u nginx` or `sudo journalctl -u postgresql`
4. Ensure your server meets minimum requirements (1GB RAM, 10GB storage)
5. Verify domain DNS settings point to your server IP

## Quick Commands Reference

```bash
# Deployment
./validate-deployment.sh          # Validate setup
sudo ./deploy.sh                  # Deploy to production

# Application Management
sudo -u www-data pm2 logs crypto-airdrop    # View logs
sudo -u www-data pm2 restart crypto-airdrop # Restart app
sudo systemctl reload nginx                 # Reload web server

# Database Access
sudo -u postgres psql -d crypto_airdrop_db  # Connect to database
cd /var/www/crypto-airdrop && npm run db:push # Update schema

# SSL Setup
sudo certbot --nginx -d yourdomain.com      # Get SSL certificate
```

Your crypto airdrop platform is now ready for production use!