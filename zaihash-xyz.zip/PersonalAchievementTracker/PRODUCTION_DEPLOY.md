# Production Deployment Guide

## Quick Start

Deploy your Crypto Airdrop Platform to Ubuntu/VPS in one command:

```bash
sudo chmod +x deploy.sh
sudo ./deploy.sh
```

## What the Script Does

✅ **System Setup**
- Installs Node.js 20, PostgreSQL, Nginx, PM2
- Configures firewall and security settings
- Sets up fail2ban protection

✅ **Database Configuration**  
- Creates secure PostgreSQL database
- Uses existing schema from your development setup
- Automatically runs migrations and seeds data

✅ **Application Deployment**
- Builds and optimizes your application
- Configures environment variables
- Sets up PM2 process management

✅ **Web Server Setup**
- Configures Nginx reverse proxy
- Enables WebSocket support
- Sets up SSL-ready configuration

## Environment Variables

The script automatically creates these environment variables:

```bash
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://crypto_user:password@localhost:5432/crypto_airdrop_db
SESSION_SECRET=auto-generated
```

## After Deployment

### 1. Access Your Application
```
http://your-domain.com
```

### 2. Default Admin Login
- Username: `admin`
- Password: `admin123`

**⚠️ Change this password immediately after first login**

### 3. Set Up SSL (Recommended)
```bash
sudo certbot --nginx -d your-domain.com -d www.your-domain.com
```

### 4. Management Commands
```bash
# View application logs
sudo -u www-data pm2 logs crypto-airdrop

# Restart application
sudo -u www-data pm2 restart crypto-airdrop

# Check application status
sudo -u www-data pm2 status

# Reload Nginx configuration
sudo systemctl reload nginx

# View database
sudo -u postgres psql -d crypto_airdrop_db
```

## Troubleshooting

### Application Won't Start
```bash
sudo -u www-data pm2 logs crypto-airdrop
```

### Database Issues
```bash
sudo systemctl status postgresql
sudo -u postgres psql -d crypto_airdrop_db -c "SELECT 1;"
```

### Nginx Problems
```bash
sudo nginx -t
sudo systemctl status nginx
```

### Port Already in Use
```bash
sudo lsof -i :3000
sudo systemctl stop apache2  # If Apache is running
```

## Security Features

- Firewall configured (only ports 22, 80, 443, 3000 open)
- Fail2ban protection against brute force attacks
- Nginx rate limiting (10 requests/second)
- Secure database with random passwords
- Log rotation configured

## File Locations

- Application: `/var/www/crypto-airdrop/`
- Logs: `/var/log/pm2/crypto-airdrop*.log`
- Nginx config: `/etc/nginx/sites-available/crypto-airdrop`
- Environment: `/var/www/crypto-airdrop/.env`

## Custom Domain Setup

To use your own domain:

```bash
export DOMAIN=yourdomain.com
sudo ./deploy.sh
```

Then point your domain's DNS A record to your server's IP address.

## Support

If you encounter issues:

1. Check the logs using the commands above
2. Ensure your server has at least 1GB RAM and 10GB storage
3. Verify your domain DNS settings if using a custom domain
4. Make sure ports 80 and 443 are not blocked by your hosting provider