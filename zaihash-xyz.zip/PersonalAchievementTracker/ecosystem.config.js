module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'dist/index.js',
    cwd: '/var/www/crypto-airdrop',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/pm2/crypto-airdrop-error.log',
    out_file: '/var/log/pm2/crypto-airdrop-out.log',
    log_file: '/var/log/pm2/crypto-airdrop.log'
  }]
};