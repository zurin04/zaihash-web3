# Crypto Airdrop Platform

A comprehensive crypto learning and engagement platform that empowers users to explore, learn, and participate in cryptocurrency ecosystems through advanced user management, creator application workflows, and role-based access controls.

## Quick Production Deployment

### One-Click Setup (Recommended)

Deploy your entire platform in minutes:

```bash
# Upload your files to your VPS, then run:
chmod +x setup.sh
sudo ./setup.sh
```

Choose option 1 for complete automated deployment. The script will:
- Install Node.js, PostgreSQL, Nginx, PM2
- Configure security (firewall, fail2ban) 
- Set up SSL-ready web server
- Build and deploy your application
- Provide complete access credentials

**Your site will be ready at**: `http://your-server-ip`

**Default login**: admin / admin123

The setup script handles everything automatically with a simple confirmation.

## Development Setup

### Prerequisites
- Node.js 18+
- PostgreSQL database

### Local Development

```bash
# Clone and install
git clone <repository-url>
cd crypto-airdrop-platform
npm install

# Setup environment
cp .env.example .env
# Edit .env with your database URL

# Initialize database
npm run db:push
npm run db:seed

# Start development
npm run dev
```

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Backend**: Express.js + TypeScript  
- **Database**: PostgreSQL + Drizzle ORM
- **Styling**: Tailwind CSS + shadcn/ui
- **Authentication**: Passport.js + Web3 wallet support
- **Real-time**: WebSocket chat system

## Features

- **User Management**: Registration, authentication, role-based access
- **Web3 Integration**: Wallet connection and SIWE authentication
- **Airdrop Management**: Create, manage, and track crypto airdrops
- **Real-time Chat**: Live community chat with admin controls
- **Creator System**: Application workflow for content creators
- **Crypto Prices**: Live cryptocurrency price feeds
- **Admin Dashboard**: Comprehensive admin panel
- **Mobile Responsive**: Optimized for all devices

## Management Commands

After deployment:

```bash
# View application logs
sudo -u www-data pm2 logs crypto-airdrop

# Restart application  
sudo -u www-data pm2 restart crypto-airdrop

# Check system status
sudo -u www-data pm2 status
systemctl status nginx postgresql

# Database access
sudo -u postgres psql -d crypto_airdrop_db
```

## Security Notes

- Change default admin password immediately
- Setup SSL: `certbot --nginx -d yourdomain.com`
- All credentials saved in `/root/deployment-info.txt`
- Firewall and fail2ban configured automatically

## Support

Check deployment info and logs:
```bash
# View deployment credentials
cat /root/deployment-info.txt

# View application logs
sudo -u www-data pm2 logs crypto-airdrop

# Check system status
systemctl status nginx postgresql
sudo -u www-data pm2 status
```