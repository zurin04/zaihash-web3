import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import MainLayout from "@/components/layout/main-layout";
import Footer from "@/components/layout/footer";
import AirdropList from "@/components/airdrops/airdrop-list";
import { Airdrops, Category } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger, 
  SelectValue
} from "@/components/ui/select";

export default function AirdropsPage() {
  const params = useParams<{ categoryId?: string }>();
  const [, navigate] = useLocation();
  const categoryId = params.categoryId ? parseInt(params.categoryId, 10) : undefined;
  
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | undefined>(categoryId);
  
  // Fetch airdrops - if categoryId is provided, fetch only that category's airdrops
  const { data: airdrops = [], isLoading: airdropsLoading } = useQuery<Airdrops[]>({
    queryKey: categoryId ? ["/api/categories", categoryId, "airdrops"] : ["/api/airdrops"],
    queryFn: async ({ queryKey }) => {
      // If categoryId is present, fetch from the category-specific endpoint
      if (categoryId) {
        const res = await fetch(`/api/categories/${categoryId}/airdrops`);
        if (!res.ok) throw new Error('Failed to fetch category airdrops');
        return res.json();
      } else {
        // For all airdrops
        const res = await fetch("/api/airdrops");
        if (!res.ok) throw new Error('Failed to fetch airdrops');
        return res.json();
      }
    }
  });
  
  // Fetch categories
  const { data: categories = [], isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // If categoryId changes from params, update the selectedCategoryId
  useEffect(() => {
    setSelectedCategoryId(categoryId);
  }, [categoryId]);
  
  // Handle category change
  const handleCategoryChange = (value: string) => {
    const newCategoryId = value === "all" ? undefined : parseInt(value, 10);
    setSelectedCategoryId(newCategoryId);
    
    // Navigate to the appropriate URL
    if (newCategoryId) {
      navigate(`/airdrops/category/${newCategoryId}`);
    } else {
      navigate('/airdrops');
    }
  };
  
  // Get current category name
  const currentCategory = categories.find(cat => cat.id === selectedCategoryId);
  
  // Extract all unique tags
  const allTags = Array.from(
    new Set(
      airdrops.flatMap(airdrop => airdrop.tags || [])
    )
  );
  
  // Toggle tag selection
  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter(t => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };
  
  // Filter airdrops based on search, selected tags, and category
  const filteredAirdrops = airdrops.filter(airdrop => {
    const matchesSearch = !searchTerm || 
      airdrop.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      airdrop.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesTags = selectedTags.length === 0 ||
      selectedTags.some(tag => airdrop.tags?.includes(tag));
    
    const matchesCategory = !selectedCategoryId || airdrop.category_id === selectedCategoryId;
    
    return matchesSearch && matchesTags && matchesCategory;
  });

  // Page title based on category
  const pageTitle = currentCategory 
    ? `${currentCategory.name} Airdrops - Crypto Airdrop Task Hub` 
    : "All Airdrops - Crypto Airdrop Task Hub";

  // Page description based on category
  const pageDescription = currentCategory
    ? `Browse and filter ${currentCategory.name} airdrops, find task tutorials, and complete requirements to earn rewards.`
    : "Browse and filter all crypto airdrops, find task tutorials, and complete requirements to earn rewards.";

  const isLoading = airdropsLoading || categoriesLoading;

  return (
    <MainLayout title={pageTitle}>
      <div className="hero-bg p-6 md:p-10 rounded-xl">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            {currentCategory ? (
              <><span className="text-primary">{currentCategory.name}</span> Airdrops</>
            ) : (
              <>All <span className="text-primary">Airdrops</span></>
            )}
          </h1>
          <p className="text-gray-300 mb-6">{pageDescription}</p>
          
          <div className="bg-card p-4 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="relative">
                <Input 
                  type="text" 
                  placeholder="Search airdrops..." 
                  className="pl-10 bg-background"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              
              <div className="relative">
                <Select 
                  value={selectedCategoryId?.toString() || "all"} 
                  onValueChange={handleCategoryChange}
                >
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categoriesLoading ? (
                      <SelectItem value="loading" disabled>Loading categories...</SelectItem>
                    ) : categories && categories.length > 0 ? (
                      categories.map(category => (
                        <SelectItem key={category.id} value={category.id.toString()}>
                          {category.name}
                        </SelectItem>
                      ))
                    ) : null}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mb-2">
              <h3 className="text-sm font-medium text-gray-300 mb-2">Filter by tags:</h3>
              <div className="flex flex-wrap gap-2">
                {allTags.map(tag => (
                  <Badge 
                    key={tag}
                    variant={selectedTags.includes(tag) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => toggleTag(tag)}
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="p-6 md:p-10">
        <div className="max-w-5xl mx-auto">
          {airdropsLoading || categoriesLoading ? (
            <div className="flex justify-center py-12">
              <svg className="animate-spin h-8 w-8 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            </div>
          ) : filteredAirdrops.length > 0 ? (
            <>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-white">
                  Showing {filteredAirdrops.length} of {airdrops.length} airdrops
                </h2>
              </div>
              <AirdropList airdrops={filteredAirdrops} />
            </>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-muted-foreground mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="text-xl font-bold text-white mb-2">No results found</h3>
                <p className="text-gray-400 text-center max-w-md">
                  We couldn't find any airdrops matching your search criteria. Try adjusting your filters or search terms.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      
      <Footer />
    </MainLayout>
  );
}
